﻿CREATE TABLE [dbo].[User](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[Title] [varchar](50) NULL,
	[Email] [varchar](50) NULL,
	[ContactType] [varchar](50) NULL,
	[ContactTypeCode] [varchar](20) NULL,
	[ContactId] [varchar](50) NULL,
	[CustomerName] [varchar](50) NULL,
	[Phone] [varchar](20) NULL,
	[Mobile] [varchar](20) NULL,
	[UserName] [varchar](50) NULL,
	[LocaleSidKey] [varchar](20) NULL,
	[ProfileId] [varchar](50) NULL,
	[LanguageLocaleKey] [varchar](20) NULL,
	[EmailEncodingKey] [varchar](20) NULL,
	[TimeZoneSidKey] [varchar](20) NULL,
	[VaultexViewInternalUser] [bit] NULL,
	[VaultexViewRole] [varchar](50) NULL,
	[VaultexViewAccess] [varchar](50) NULL,
	[AccountStatus] [varchar](20) NULL,
	[FirstTimeExternalUser] [bit] NULL,
	[TableauReportingUser] [bit] NULL,
	[CreatedBy] [varchar](100) NOT NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[UpdatedBy] [varchar](100) NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[DeletedBy] [varchar](100) NULL,
	[DeletedOn] [datetime2](7) NULL,
	[RowLockVersion] [timestamp] NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_dbo_User_CreatedBy]  DEFAULT (suser_sname()) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_dbo_User_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_dbo_User_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

