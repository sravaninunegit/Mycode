
CREATE TABLE [dbo].[Contact](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL ,
	[Title] [varchar](50) NULL,
	[Email] [varchar](50) NULL,
	[ContactType] [varchar](50) NULL,
	[ContactTypeCode] [varchar](20) NULL,
	[ContactId] [varchar](50) NULL,
	[CustomerName] [varchar](50) NULL,
	[Phone] [varchar](20) NULL,
	[Mobile] [varchar](20) NULL,
	[IsAdminUser] [bit]  NULL,
	[IsOperatorOrdering] [bit]  NULL,
	[IsOperatorReporting] [bit]  NULL,
	[CreatedBy] [varchar](100) NOT NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[UpdatedBy] [varchar](100) NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[DeletedBy] [varchar](100) NULL,
	[DeletedOn] [datetime2](7) NULL,
	[RowLockVersion] [timestamp] NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_Contact] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Contact] ADD  CONSTRAINT [DF_dbo_Contact_CreatedBy]  DEFAULT (suser_sname()) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[Contact] ADD  CONSTRAINT [DF_dbo_Contact_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[Contact] ADD  CONSTRAINT [DF_dbo_Contact_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO