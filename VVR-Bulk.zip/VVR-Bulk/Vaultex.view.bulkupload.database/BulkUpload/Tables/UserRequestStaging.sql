﻿CREATE TABLE [dbo].[UserRequestStaging](
	[UserRequestId] [bigint] IDENTITY(1,1) NOT NULL,
	[StoreName] [varchar](50) NULL,
	[CustomerNo] [bigint] NULL,
	[Title] [varchar](50) NULL,
	[UserFirstName] [varchar](50) NULL,
	[UserSurName] [varchar](20) NULL,
	[UserEmailAddress] [varchar](50) NULL,
	[MobileNumber] [varchar](20) NULL,
	[IsAdminUser] [bit] NOT NULL,
	[IsOperatorOrdering] [bit] NOT NULL,
	[IsOperatorReporting] [bit] NOT NULL,
	[CreatedBy] [varchar](100) NOT NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[UpdatedBy] [varchar](100) NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[DeletedBy] [varchar](100) NULL,
	[DeletedOn] [datetime2](7) NULL,
	[RowLockVersion] [timestamp] NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_UserRequest] PRIMARY KEY CLUSTERED 
(
	[UserRequestId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[UserRequestStaging] ADD  CONSTRAINT [DF_dbo_UserRequestStaging_CreatedBy]  DEFAULT (suser_sname()) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[UserRequestStaging] ADD  CONSTRAINT [DF_dbo_UserRequestStaging_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[UserRequestStaging] ADD  CONSTRAINT [DF_dbo_UserRequestStaging_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO



