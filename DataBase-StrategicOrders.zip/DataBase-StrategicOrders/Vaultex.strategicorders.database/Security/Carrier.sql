﻿
CREATE SCHEMA [Carrier]
    AUTHORIZATION [dbo];