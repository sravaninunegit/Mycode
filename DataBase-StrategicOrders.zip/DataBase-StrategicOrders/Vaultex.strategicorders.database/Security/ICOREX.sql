﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 02/10/2024
-- Description: Scheme for "ICOREX"
-- History: 02/10/2024 : Resource 503436 : SOTPT-642
-- ==================================================================
CREATE SCHEMA ICOREX
    AUTHORIZATION [dbo];
