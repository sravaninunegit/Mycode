﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 13/08/2024
-- Description: Scheme for "Error"
-- History: 13/08/2024 : Resource 503436 : SOTPT-264
-- ==================================================================
CREATE SCHEMA [Error]
    AUTHORIZATION [dbo];
