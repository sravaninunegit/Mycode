﻿-- ==================================================================
-- Author:      Resource 504278
-- Create Date: 04/11/2024
-- History: 04/11/2024 : Resource 504278 : SOTPT-766
-- ==================================================================
CREATE SCHEMA CallCentre
	AUTHORIZATION [dbo];
