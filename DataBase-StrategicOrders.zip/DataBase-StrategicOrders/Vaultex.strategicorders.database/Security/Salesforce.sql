﻿-- ==================================================================
-- Author:      Resource 504278
-- Create Date: 15/10/2024
-- History: 15/10/2024 : Resource 504278 : SOTPT-708
-- ==================================================================
CREATE SCHEMA Salesforce
	AUTHORIZATION [dbo];
