﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]	
			   Created on 31/07/2024
--------------------------------------------------------------------------------------
*/
:r StrategicOrders\Data\Reference_OrderSource_Load.sql
:r StrategicOrders\Data\Reference_CashProcessing_Load.sql
:r StrategicOrders\Data\Reference_OrderDenomination_Load.sql
:r StrategicOrders\Data\Reference_Product_Load.sql
:r StrategicOrders\Data\Reference_ServiceType_Load.sql
:r StrategicOrders\Data\Reference_Service_Load.sql
:r StrategicOrders\Data\Reference_ProductService_Load.sql
:r StrategicOrders\Data\Reference_DayOfWeek_Load.sql
:r StrategicOrders\Data\Reference_ErrorCode_Load.sql
:r StrategicOrders\Data\Reference_CashCentre_Load.sql
:r StrategicOrders\Data\Carrier_Carrier_Load.sql
:r StrategicOrders\Data\Carrier_Depot_Load.sql
:r StrategicOrders\Data\Reference_CassetteType_Load.sql
:r StrategicOrders\Data\Reference_Currency_Load.sql
:r StrategicOrders\Data\Reference_Denomination_Load.sql
:r StrategicOrders\Data\Reference_DepotType_Load.sql
:r StrategicOrders\Data\Reference_ErrorCode_Load.sql
:r StrategicOrders\Data\Reference_Issuer_Load.sql
:r StrategicOrders\Data\Reference_QualityType_Load.sql
:r StrategicOrders\Data\Reference_Quality_Load.sql
:r StrategicOrders\Data\Reference_RemoteDeviceManufacturer_Load.sql
:r StrategicOrders\Data\Reference_RemoteDeviceModel_Load.sql
:r StrategicOrders\Data\CustomerStatus_Load.sql
