﻿CREATE TABLE [Output].[FileOut]
(
	[FileOutID]				BIGINT IDENTITY(1,1) NOT NULL,
	[FileName]				VARCHAR (100) NOT NULL,
	[CreatedBy]				VARCHAR (100) NULL,
	[CreatedOn]				DATETIME2 (7) NOT NULL,
	[UpdatedBy]				VARCHAR (100) NULL,
	[UpdatedOn]				DATETIME2 (7) NULL,
	[DeletedBy]				VARCHAR (100) NULL,
	[DeletedOn]				DATETIME2 (7) NULL,
	[RowLockVersion]		ROWVERSION NOT NULL,
	[IsActive]				BIT NOT NULL,
	[IsAmalgamatedCageOrder] BIT NOT NULL
    CONSTRAINT [PK_FileOut] PRIMARY KEY CLUSTERED ([FileOutID] ASC)
)
GO
ALTER TABLE [Output].[FileOut]
ADD CONSTRAINT [DF_Output_FileOut_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO
ALTER TABLE [Output].[FileOut]
ADD CONSTRAINT [DF_Output_FileOut_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
ALTER TABLE [Output].[FileOut]
ADD CONSTRAINT [DF_Output_FileOut_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO