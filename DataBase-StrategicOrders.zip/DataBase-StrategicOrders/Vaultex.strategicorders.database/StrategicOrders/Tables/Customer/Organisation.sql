﻿CREATE TABLE [Customer].[Organisation]
(
    [OrganisationID]                    INT             IDENTITY (1, 1) NOT NULL,
	[OrganisationIdentifier]            VARCHAR (50)    NOT NULL, 
    [OrganisationName]                  VARCHAR (50)    NOT NULL, 
    [CreditLimit]                       BIGINT          NOT NULL, 
    [CreatedBy]                         VARCHAR(100)     NOT NULL,
    [CreatedOn]                         DATETIME2 (7)   NOT NULL,
    [UpdatedBy]                         VARCHAR (100)    NULL,
    [UpdatedOn]                         DATETIME2 (7)   NULL,
    [DeletedBy]                         VARCHAR (100)    NULL,
    [DeletedOn]                         DATETIME2 (7)   NULL,
    [RowLockVersion]                    ROWVERSION      NOT NULL,
    [IsActive]                          BIT             NOT NULL
    CONSTRAINT [PK_Organisation] PRIMARY KEY CLUSTERED 
(
	[OrganisationID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_OrganisationIdentifier] UNIQUE NONCLUSTERED 
(
	[OrganisationIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Customer].[Organisation]
ADD CONSTRAINT [DF_Customer_Organisation_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Customer].[Organisation]
ADD CONSTRAINT [DF_Customer_Organisation_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Customer].[Organisation]
ADD CONSTRAINT [DF_Customer_Organisation_IsActive]
    DEFAULT (1) FOR [IsActive]
GO