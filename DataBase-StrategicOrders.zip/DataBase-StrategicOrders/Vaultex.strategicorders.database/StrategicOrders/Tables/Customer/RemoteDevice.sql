﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Customer].[RemoteDevice] from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Customer].[RemoteDevice] (
    [RemoteDeviceID]      BIGINT        IDENTITY (1, 1) NOT NULL,
    [CustomerID]          BIGINT        NOT NULL,
    [RemoteDeviceModelID] BIGINT        NOT NULL,
    [CassetteTypeID]      BIGINT        NOT NULL,
    [IsDyeCassette]       BIT           NOT NULL,
    [MaxNotes]            INT           NOT NULL,
    [CreatedBy]           VARCHAR (50)  NOT NULL,
    [CreatedOn]           DATETIME2 (7) NOT NULL,
    [UpdatedOn]           DATETIME2 (7) NULL,
    [UpdatedBy]           VARCHAR (50)  NULL,
    [DeletedBy]           VARCHAR (50)  NULL,
    [DeletedOn]           DATETIME2 (7) NULL,
    [RowLockVersion]      ROWVERSION    NOT NULL,
    [IsActive]            BIT           NOT NULL,
    CONSTRAINT [PK_RemoteDevice] PRIMARY KEY CLUSTERED ([RemoteDeviceID] ASC),
    CONSTRAINT [FK_CassetteType_RemoteDevice] FOREIGN KEY ([CassetteTypeID]) REFERENCES [Reference].[CassetteType] ([CassetteTypeID]),
    CONSTRAINT [FK_Customer_RemoteDevice] FOREIGN KEY ([CustomerID]) REFERENCES [Customer].[Customer] ([CustomerID]),
    CONSTRAINT [FK_RemoteDeviceModel_RemoteDevice] FOREIGN KEY ([RemoteDeviceModelID]) REFERENCES [Reference].[RemoteDeviceModel] ([RemoteDeviceModelID]),
    CONSTRAINT [UQ_RemoteDevice] UNIQUE NONCLUSTERED ([CustomerID] ASC)
);
