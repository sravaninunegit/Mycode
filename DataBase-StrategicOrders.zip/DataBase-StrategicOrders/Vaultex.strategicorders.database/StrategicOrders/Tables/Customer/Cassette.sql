﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Customer].[Cassette] from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Customer].[Cassette] (
    [CassetteID]     BIGINT        IDENTITY (1, 1) NOT NULL,
    [RemoteDeviceID] BIGINT        NOT NULL,
    [DenominationID] BIGINT        NOT NULL,
    [IssuerID]       BIGINT        NOT NULL,
    [CurrencyID]     BIGINT        NOT NULL,
    [CassetteNumber] VARCHAR (50)  NOT NULL,
    [CreatedBy]      VARCHAR (50)  NOT NULL,
    [CreatedOn]      DATETIME2 (7) NOT NULL,
    [UpdatedBy]      VARCHAR (50)  NULL,
    [UpdatedOn]      DATETIME2 (7) NULL,
    [RowLockVersion] ROWVERSION    NOT NULL,
    [DeletedBy]      VARCHAR (50)  NULL,
    [DeletedOn]      DATETIME2 (7) NULL,
    [IsActive]       BIT           NOT NULL,
    CONSTRAINT [PK_Cassette] PRIMARY KEY CLUSTERED ([CassetteID] ASC),
    CONSTRAINT [FK_Currency_Cassette] FOREIGN KEY ([CurrencyID]) REFERENCES [Reference].[Currency] ([CurrencyID]),
    CONSTRAINT [FK_Denomination_Cassette] FOREIGN KEY ([DenominationID]) REFERENCES [Reference].[Denomination] ([DenominationID]),
    CONSTRAINT [FK_Issuer_Cassette] FOREIGN KEY ([IssuerID]) REFERENCES [Reference].[Issuer] ([IssuerID]),
    CONSTRAINT [FK_RemoteDevice_Cassette] FOREIGN KEY ([RemoteDeviceID]) REFERENCES [Customer].[RemoteDevice] ([RemoteDeviceID]),
    CONSTRAINT [UQ_Cassette] UNIQUE NONCLUSTERED ([RemoteDeviceID] ASC, [CassetteNumber] ASC)
);
