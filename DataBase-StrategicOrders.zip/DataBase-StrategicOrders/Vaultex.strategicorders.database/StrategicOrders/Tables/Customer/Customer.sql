﻿CREATE TABLE [Customer].[Customer] (
    [CustomerID]        BIGINT        IDENTITY (1, 1) NOT NULL,    
    [CustomerNumber]    VARCHAR (17)  NOT NULL,
    [CustomerName]      VARCHAR (50)  NOT NULL, 
    [CustomerStatusID] [bigint] NOT NULL,
    [CreatedBy]         VARCHAR (100)  NOT NULL,
    [CreatedOn]         DATETIME2 (7) NOT NULL,    
    [RowLockVersion]    ROWVERSION    NOT NULL,   
    [CreditLimit]       BIGINT        NULL   ,
    [IsActive]       BIT           NOT NULL
 CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED 
(
	[CustomerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_CustomerNumber] UNIQUE NONCLUSTERED 
(
	[CustomerNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [Customer].[Customer]
ADD CONSTRAINT [DF_Customer_Customer_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Customer].[Customer]
ADD CONSTRAINT [DF_Customer_Customer_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO
ALTER TABLE [Customer].[Customer]
ADD CONSTRAINT [DF_Customer_Customer_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
ALTER TABLE [Customer].[Customer]  WITH NOCHECK ADD  CONSTRAINT [FK_CustomerStatus_Customer] FOREIGN KEY([CustomerStatusID])
REFERENCES [Reference].[CustomerStatus] ([CustomerStatusID])
GO





