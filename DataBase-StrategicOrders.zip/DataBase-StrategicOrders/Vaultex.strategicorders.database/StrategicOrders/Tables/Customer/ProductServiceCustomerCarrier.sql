﻿CREATE TABLE [Customer].[ProductServiceCustomerCarrier]
(
	[ProductServiceCustomerCarrierID] [bigint] IDENTITY(1,1) NOT NULL,
	[ProductServiceCustomerID] [bigint] NOT NULL,
	[DayOfWeekID] [bigint] NOT NULL,
	[CarrierRouteCode] [varchar](50) NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[UpdatedBy] [varchar](50) NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[DeletedBy] [varchar](50) NULL,
	[DeletedOn] [datetime2](7) NULL,
	[RowLockVersion] [timestamp] NOT NULL,
	[IsActive] [bit] NOT NULL
	CONSTRAINT [PK_ProductServiceCustomerCarrier] PRIMARY KEY CLUSTERED ([ProductServiceCustomerCarrierID] ASC),
	CONSTRAINT [FK_DayOfWeek_ProductServiceCustomerCarrier] FOREIGN KEY ([DayOfWeekID]) REFERENCES [Reference].[DayOfWeek] ([DayOfWeekID]),
	CONSTRAINT [FK_ProductServiceCustomer_ProductServiceCustomerCarrier] FOREIGN KEY ([ProductServiceCustomerID]) REFERENCES [Customer].[ProductServiceCustomer] ([ProductServiceCustomerID]),
	CONSTRAINT [UQ_ProductServiceCustomerCarrier] UNIQUE NONCLUSTERED ([ProductServiceCustomerID] ASC, [DayOfWeekID] ASC)

)
GO


ALTER TABLE [Customer].[ProductServiceCustomerCarrier]
ADD CONSTRAINT [DF_Customer_ProductServiceCustomerCarrier_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Customer].[ProductServiceCustomerCarrier]
ADD CONSTRAINT [DF_Customer_ProductServiceCustomerCarrier_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Customer].[ProductServiceCustomerCarrier]
ADD CONSTRAINT [DF_Customer_ProductServiceCustomerCarrier_IsActive]
    DEFAULT (1) FOR [IsActive]
GO