﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Customer].[ProductServiceCustomer] from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Customer].[ProductServiceCustomer] (
    [ProductServiceCustomerID] BIGINT        IDENTITY (1, 1) NOT NULL,
    [ProductServiceID]         BIGINT        NOT NULL,
    [CustomerID]               BIGINT        NOT NULL,
    [CashCentreCode]           INT           NULL,
    [ISAClientCode]            VARCHAR(63)   NULL,
    [CreatedBy]                VARCHAR (50)  NOT NULL,
    [CreatedOn]                DATETIME2 (7) NOT NULL,
    [UpdatedBy]                VARCHAR (50)  NULL,
    [UpdatedOn]                DATETIME2 (7) NULL,
    [DeletedBy]                VARCHAR (50)  NULL,
    [DeletedOn]                DATETIME2 (7) NULL,
    [RowLockVersion]           ROWVERSION    NOT NULL,
    [IsActive]                 BIT           NOT NULL,
    CONSTRAINT [PK_ProductServiceCustomer] PRIMARY KEY CLUSTERED ([ProductServiceCustomerID] ASC),
    CONSTRAINT [FK_Customer_ProductServiceCustomer] FOREIGN KEY ([CustomerID]) REFERENCES [Customer].[Customer] ([CustomerID]),
    CONSTRAINT [FK_ProductService_ProductServiceCustomer] FOREIGN KEY ([ProductServiceID]) REFERENCES [Reference].[ProductService] ([ProductServiceID]),
    CONSTRAINT [UQ_ProductServiceCustomer] UNIQUE NONCLUSTERED ([ProductServiceID] ASC, [CustomerID] ASC, [CashCentreCode] ASC)
);
