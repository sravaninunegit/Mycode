﻿CREATE TABLE [Customer].[CustomerResiliencyMap]
(
	[CustomerResiliencyMapID]	INT             IDENTITY (1, 1) NOT NULL,
	[OrganisationID]			INT             NOT NULL,
	[CustomerLocationID]		VARCHAR(100)		NOT NULL,
	[CustomerNumber]			VARCHAR(20)		NOT NULL,
	[CreatedBy]                 VARCHAR(100)     NOT NULL,
    [CreatedOn]                 DATETIME2 (7)   NOT NULL,
    [RowLockVersion]            ROWVERSION      NOT NULL,
    [IsActive]                  BIT             NOT NULL
	CONSTRAINT [PK_CustomerResiliencyMap] PRIMARY KEY CLUSTERED ([CustomerResiliencyMapID] ASC),
)
GO
ALTER TABLE [Customer].[CustomerResiliencyMap]  WITH CHECK ADD  CONSTRAINT [FK_Organisation_CustomerResiliencyMap] FOREIGN KEY([OrganisationID])
REFERENCES [Customer].[Organisation] ([OrganisationID])
GO

ALTER TABLE [Customer].[CustomerResiliencyMap] CHECK CONSTRAINT [FK_Organisation_CustomerResiliencyMap]
GO

ALTER TABLE [Customer].[CustomerResiliencyMap]
ADD CONSTRAINT [DF_Customer_CustomerResiliencyMap_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Customer].[CustomerResiliencyMap]
ADD CONSTRAINT [DF_Customer_CustomerResiliencyMap_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Customer].[CustomerResiliencyMap]
ADD CONSTRAINT [DF_Customer_CustomerResiliencyMap_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
