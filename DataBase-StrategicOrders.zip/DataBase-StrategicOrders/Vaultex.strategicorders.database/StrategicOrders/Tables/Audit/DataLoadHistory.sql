﻿CREATE TABLE [Audit].[DataLoadHistory]
(
    [AuditLogId] BIGINT IDENTITY(1, 1) NOT NULL,
	[filename]					VARCHAR(100) NOT NULL,
    [DateTimeReceived] 			DATETIME2(7) NOT NULL,
    [PipelineName]				[varchar](100) NOT NULL,
    [PipelineRunID]				[varchar](100) NOT NULL,
    [Status] 					VARCHAR(30) NOT NULL,	--(Success|File Validation failure|Error)
    [ConfirmationNotification]	VARCHAR(100) NOT NULL,
    [RejectionNotification]		VARCHAR(100) NOT NULL,
    [ActionTaken]				VARCHAR(100) NOT NULL,
    [TotalNoOfOrders]			INT NOT NULL,
    [TotalNoOfValidOrders]		INT NOT NULL,
    [TotalNoOfRejectedOrders]	INT NOT NULL,
    [StartTime]					DATETIME2 NOT NULL,
    [EndTime]					DATETIME2 NOT NULL,
    [RowLockVersion]			[timestamp] NOT NULL,
    [OrderSourceId]             BIGINT  NULL,
    [SalesforceBatchId]         UNIQUEIDENTIFIER NULL,
    [CreatedBy]                 VARCHAR(100) NOT NULL,
    [CreatedOn]                 DATETIME2 NOT NULL,
    [UpdatedBy]                 VARCHAR(100) NULL,
    [UpdatedOn]                 DATETIME2 NULL,
    [IsActive]					[bit] NOT NULL
    CONSTRAINT [PK_DataLoadHistory] PRIMARY KEY CLUSTERED ([AuditLogId] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Audit].[DataLoadHistory]
ADD CONSTRAINT [DF_Audit_DataLoadHistory_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Audit].[DataLoadHistory]
ADD CONSTRAINT [DF_Audit_DataLoadHistory_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Audit].[DataLoadHistory]
ADD CONSTRAINT [DF_Audit_DataLoadHistory_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
ALTER TABLE [Audit].[DataLoadHistory]  WITH CHECK ADD  CONSTRAINT [FK_DataLoadHistory_ToOrderSource] FOREIGN KEY([OrderSourceId])
REFERENCES [Reference].[OrderSource] ([OrderSourceId])
GO

ALTER TABLE [Audit].[DataLoadHistory] CHECK CONSTRAINT [FK_DataLoadHistory_ToOrderSource]
GO