﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 13/08/2024
-- Description: Table for file load validation errors.
-- History: 13/08/2024 : Resource 503436 : SOTPT-264
-- ==================================================================
CREATE TABLE [Error].[Error] (
	[ErrorId] [BIGINT] IDENTITY(1,1) NOT NULL,
	[ErrorCodeId] [BIGINT] NOT NULL,
    [FileError] [BIGINT] NULL,
	[OrderFailedId] [BIGINT] NULL,
	[OrderDetailFailedId] [BIGINT] NULL,
    [CreatedBy] VARCHAR(100)  NOT NULL,
    [CreatedOn] DATETIME2 (7) NOT NULL,
    [UpdatedBy] VARCHAR (100) NULL,
    [UpdatedOn] DATETIME2 (7) NULL,
    [DeletedBy] VARCHAR (100) NULL,
    [DeletedOn] DATETIME2 (7) NULL,
    [RowLockVersion] ROWVERSION NOT NULL,
    [IsActive] BIT NOT NULL
    CONSTRAINT [FK_ErrorCode_Errors] FOREIGN KEY ([ErrorCodeId]) REFERENCES [Reference].[ErrorCode] ([ErrorCodeId]),
	CONSTRAINT [FK_OrderFailed_Errors] FOREIGN KEY ([OrderFailedId]) REFERENCES [Orders].[OrderFailed] ([OrderFailedId]),
	CONSTRAINT [FK_OrderDetailFailed_Errors] FOREIGN KEY ([OrderDetailFailedId]) REFERENCES [Orders].[OrderDetailFailed] ([OrderDetailFailedID]),
    CONSTRAINT [CK_OnlyOneError] CHECK (IIF([FileError] IS NULL, 0, 1) + IIF([OrderFailedId] IS NULL, 0, 1) + IIF([OrderDetailFailedId] IS NULL, 0, 1) = 1),
	CONSTRAINT [PK_ErrorId] PRIMARY KEY CLUSTERED 
	(
		[ErrorId] ASC
	) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Error].[Error]
ADD CONSTRAINT [DF_Error_Error_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Error].[Error]
ADD CONSTRAINT [DF_Error_Error_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Error].[Error]
ADD CONSTRAINT [DF_Error_Error_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
