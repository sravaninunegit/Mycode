﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Carrier].[Carrier] from carrier domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Carrier].[Carrier](
	[CarrierID] [BIGINT] IDENTITY(1,1) NOT NULL,
	[CarrierCode] [VARCHAR](3) NOT NULL,
	[CarrierDescription] [VARCHAR](100) NOT NULL,
	[CreatedBy] [VARCHAR](50) NOT NULL,
	[CreatedOn] [DATETIME2](7) NOT NULL,
	[UpdatedBy] [VARCHAR](50) NULL,
	[UpdatedOn] [DATETIME2](7) NULL,
	[DeletedBy] [VARCHAR](50) NULL,
	[DeletedOn] [DATETIME2](7) NULL,
	[RowLockVersion] [TIMESTAMP] NOT NULL,
	[IsActive] [BIT] NOT NULL,
    CONSTRAINT PK_CarrierID PRIMARY KEY CLUSTERED (CarrierID),
    CONSTRAINT UQ_CarrierCode UNIQUE (CarrierCode)
);
