﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Carrier].[Depot] from carrier domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Carrier].[Depot](
	[DepotID] [BIGINT] IDENTITY(1,1) NOT NULL,
	[CarrierID] [BIGINT] NOT NULL, -- FK
	[DepotCode] [VARCHAR](9) NOT NULL,
	[DepotDescription] [VARCHAR](100) NOT NULL,
	[CreatedBy] [VARCHAR](50) NOT NULL,
	[CreatedOn] [DATETIME2](7) NOT NULL,
	[UpdatedBy] [VARCHAR](50) NULL,
	[UpdatedOn] [DATETIME2](7) NULL,
	[DeletedBy] [VARCHAR](50) NULL,
	[DeletedOn] [DATETIME2](7) NULL,
	[RowLockVersion] [TIMESTAMP] NOT NULL,
	[IsActive] [BIT] NOT NULL,
    CONSTRAINT PK_DepotID PRIMARY KEY CLUSTERED (DepotID),
    CONSTRAINT UQ_DepotCode UNIQUE (DepotCode)
);
GO

ALTER TABLE [Carrier].[Depot] ADD CONSTRAINT [FK_Carrier_Depot] FOREIGN KEY([CarrierID])
REFERENCES [Carrier].[Carrier] ([CarrierID])
GO

ALTER TABLE [Carrier].[Depot] CHECK CONSTRAINT [FK_Carrier_Depot]
GO
