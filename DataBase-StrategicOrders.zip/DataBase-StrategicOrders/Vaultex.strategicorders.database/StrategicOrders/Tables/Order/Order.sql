﻿CREATE TABLE [Orders].[Order]
(
    [OrderId] BIGINT IDENTITY(1, 1) NOT NULL,
    [AuditLogId] [bigint] NOT NULL,
	[OrderType] VARCHAR(1) NOT NULL,
    [LocationID] INT NULL,
    [CustomerID] BIGINT NOT NULL,
	[DeliveryDate] DATE NOT NULL,			--Might not be supplied in CCORF. Depends on Flag D
    [OrderValue] decimal(16, 2) NOT NULL,
    [OrderDateTime] DATE NOT NULL,			--Might not be supplied in CCORF. Depends on Flag D
    [RawOrderData] text,
    [CarrierRouteCode] varchar(12)  NULL,
    [CustomerReference] VARCHAR(18) NULL,
    [FileOutID]			BIGINT NULL,
    [TransformedStatus] VARCHAR(18) NULL,    
    [CashCentreID] BIGINT NOT NULL,
    [SaleforceOrderId] NVARCHAR(18) NULL,
    [IsAmalgamatedCageOrder] BIT  NULL ,--created to support amalgamated xml
    [CreatedBy] VARCHAR(100) NOT NULL, 
    [CreatedOn] DATETIME2(7) NOT NULL,
    [UpdatedBy] VARCHAR(100) NULL,
    [UpdatedOn] DATETIME2(7) NULL,
    [DeletedBy] VARCHAR(100) NULL,
    [DeletedOn] DATETIME2(7) NULL,
    [RowLockVersion] [timestamp] NOT NULL,
    [IsActive] BIT NOT NULL,
    CONSTRAINT [PK_Order] PRIMARY KEY CLUSTERED ([OrderId] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY],
    CONSTRAINT [FK_CustomerResiliencyMap_Order] FOREIGN KEY ([LocationID]) REFERENCES [Customer].[CustomerResiliencyMap] ([CustomerResiliencyMapID]),
    CONSTRAINT [FK_Customer_Order] FOREIGN KEY ([CustomerID]) REFERENCES [Customer].[Customer] ([CustomerID]),
    CONSTRAINT [FK_FileOut_Order] FOREIGN KEY ([FileOutID]) REFERENCES [Output].[FileOut] ([FileOutID])
) ON [PRIMARY]
GO

ALTER TABLE [Orders].[Order]
ADD CONSTRAINT [DF_Orders_Order_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Orders].[Order]
ADD CONSTRAINT [DF_Orders_Order_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Orders].[Order]
ADD CONSTRAINT [DF_Orders_Order_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
ALTER TABLE [Orders].[Order]  WITH CHECK ADD  CONSTRAINT [FK_Order_ToDataLoadHistory] FOREIGN KEY([AuditLogId])
REFERENCES [Audit].[DataLoadHistory] ([AuditLogId])
GO

ALTER TABLE [Orders].[Order] CHECK CONSTRAINT [FK_Order_ToDataLoadHistory]
GO