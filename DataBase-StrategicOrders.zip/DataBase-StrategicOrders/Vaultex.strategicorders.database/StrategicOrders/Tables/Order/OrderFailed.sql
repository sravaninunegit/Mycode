﻿CREATE TABLE [Orders].[OrderFailed]
(
    [OrderFailedId] BIGINT IDENTITY(1, 1) NOT NULL,
    [AuditLogId] [bigint] NOT NULL,
	[OrderType] VARCHAR(1) NOT NULL,
    [OrganisationIdentifier] VARCHAR(17) NOT NULL,  
    [LocationID] VARCHAR(17) NOT NULL, 
    [CustomerNumber] varchar(17) NOT NULL,		--Get from Customer DOmain	
	[DeliveryDate] DATE NOT NULL,			--Might not be supplied in CCORF. Depends on Flag D
    [OrderValue] decimal(16, 2) NOT NULL,
    [OrderDateTime] DATE NOT NULL,			--Might not be supplied in CCORF. Depends on Flag D
    [RawOrderData] text,
    [CarrierRouteCode] varchar(12)  NULL,
    [CustomerReference] VARCHAR(18) NULL,
    [TransformedStatus] VARCHAR(18) NULL,
    [CreatedBy] VARCHAR(100) NOT NULL, 
    [CreatedOn] DATETIME2(7) NOT NULL,
    [UpdatedBy] VARCHAR(100) NULL,
    [UpdatedOn] DATETIME2(7) NULL,
    [DeletedBy] VARCHAR(100) NULL,
    [DeletedOn] DATETIME2(7) NULL,
    [RowLockVersion] [timestamp] NOT NULL,
    [IsActive] BIT NOT NULL,    
    CONSTRAINT [PK_OrderFailed] PRIMARY KEY CLUSTERED ([OrderFailedId] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Orders].[OrderFailed]
ADD CONSTRAINT [DF_Orders_OrderFailed_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Orders].[OrderFailed]
ADD CONSTRAINT [DF_Orders_OrderFailed_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Orders].[OrderFailed]
ADD CONSTRAINT [DF_Orders_OrderFailed_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
ALTER TABLE [Orders].[OrderFailed]  WITH CHECK ADD  CONSTRAINT [FK_OrderFailed_ToDataLoadHistory] FOREIGN KEY([AuditLogId])
REFERENCES [Audit].[DataLoadHistory] ([AuditLogId])
GO

ALTER TABLE [Orders].[OrderFailed] CHECK CONSTRAINT [FK_OrderFailed_ToDataLoadHistory]
GO