﻿CREATE TABLE [Orders].[OrderDetail]
(
	[OrderDetailID] [bigint] IDENTITY(1,1) NOT NULL,
    [OrderId] [bigint] NOT NULL,
    [MediaID] BIGINT NOT NULL,          --GBPN000200022
    [Quantity]		bigint,       --Needed for ISA Order file
    [Amount]		decimal (16, 2),
    [CreatedBy] VARCHAR(100) NOT NULL,
    [RawOrderData] TEXT,
    [CreatedOn] datetime2 NOT NULL,
    [UpdatedBy] VARCHAR(100) NULL,
    [UpdatedOn] datetime2 NULL,
    [RowLockVersion] [timestamp] NOT NULL,
    [IsActive] [bit] NOT NULL, 
    CONSTRAINT [PK_OrderDetail] PRIMARY KEY CLUSTERED ([OrderDetailID] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY],
    CONSTRAINT [FK_Media_OrderDetail] FOREIGN KEY ([MediaID]) REFERENCES [Reference].[Media] ([MediaID])
) ON [PRIMARY]
GO

ALTER TABLE [Orders].[OrderDetail]
ADD CONSTRAINT [DF_Orders_OrderDetail_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Orders].[OrderDetail]
ADD CONSTRAINT [DF_Orders_OrderDetail_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Orders].[OrderDetail]
ADD CONSTRAINT [DF_Orders_OrderDetail_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
ALTER TABLE [Orders].[OrderDetail]  WITH CHECK ADD  CONSTRAINT [FK_OrderDetail_ToOrder] FOREIGN KEY([OrderId])
REFERENCES [Orders].[Order] ([OrderId])
GO

ALTER TABLE [Orders].[OrderDetail] CHECK CONSTRAINT [FK_OrderDetail_ToOrder]
GO

