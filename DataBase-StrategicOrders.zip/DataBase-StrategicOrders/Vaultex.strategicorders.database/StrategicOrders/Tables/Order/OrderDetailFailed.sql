﻿CREATE TABLE [Orders].[OrderDetailFailed]
(
	[OrderDetailFailedID] [bigint] IDENTITY(1,1) NOT NULL,
    [OrderFailedId] [bigint] NOT NULL,
    [ProductCode] VARCHAR(50) NOT NULL,	--GBPN000200022
    [Quantity]		bigint,       --Needed for ISA Order file
    [Amount]		decimal (16, 2),
    [CreatedBy] VARCHAR(100) NOT NULL,
    [ProductItemDetails] CHAR(3)  NULL,
    [RawOrderData] TEXT,
    [CreatedOn] datetime2 NOT NULL,
    [UpdatedBy] VARCHAR(100) NULL,
    [UpdatedOn] datetime2 NULL,
    [RowLockVersion] [timestamp] NOT NULL,
    [IsActive] [bit] NOT NULL, CONSTRAINT [PK_OrderDetailFailed] PRIMARY KEY CLUSTERED ([OrderDetailFailedID] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Orders].[OrderDetailFailed]
ADD CONSTRAINT [DF_Orders_OrderDetailFailed_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Orders].[OrderDetailFailed]
ADD CONSTRAINT [DF_Orders_OrderDetailFailed_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Orders].[OrderDetailFailed]
ADD CONSTRAINT [DF_Orders_OrderDetailFailed_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
ALTER TABLE [Orders].[OrderDetailFailed]  WITH CHECK ADD  CONSTRAINT [FK_OrderDetailFailed_ToOrderFailed] FOREIGN KEY([OrderFailedId])
REFERENCES [Orders].[OrderFailed] ([OrderFailedId])
GO

ALTER TABLE [Orders].[OrderDetailFailed] CHECK CONSTRAINT [FK_OrderDetailFailed_ToOrderFailed]
GO

