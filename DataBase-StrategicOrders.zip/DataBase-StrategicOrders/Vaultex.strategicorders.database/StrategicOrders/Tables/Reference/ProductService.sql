﻿CREATE TABLE [Reference].[ProductService](
	[ProductServiceID] [bigint] IDENTITY(1,1) NOT NULL,
	[ServiceID] [bigint] NOT NULL,
	[ProductID] [bigint] NOT NULL,
	[CreatedBy] [varchar](100) NOT NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[UpdatedBy] [varchar](100) NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[DeletedBy] [varchar](100) NULL,
	[DeletedOn] [datetime2](7) NULL,
	[RowLockVersion] [timestamp] NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_ProductServiceCustomer] PRIMARY KEY CLUSTERED 
(
	[ProductServiceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_ProductServiceCustomer] UNIQUE NONCLUSTERED 
(
	[ServiceID] ASC,
	[ProductID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Reference].[ProductService]  WITH CHECK ADD  CONSTRAINT [FK_Product_ProductServiceCustomer] FOREIGN KEY([ProductID])
REFERENCES [Reference].[Product] ([ProductID])
GO

ALTER TABLE [Reference].[ProductService] CHECK CONSTRAINT [FK_Product_ProductServiceCustomer]
GO

ALTER TABLE [Reference].[ProductService]  WITH CHECK ADD  CONSTRAINT [FK_Service_ProductServiceCustomer] FOREIGN KEY([ServiceID])
REFERENCES [Reference].[Service] ([ServiceID])
GO

ALTER TABLE [Reference].[ProductService] CHECK CONSTRAINT [FK_Service_ProductServiceCustomer]
GO
