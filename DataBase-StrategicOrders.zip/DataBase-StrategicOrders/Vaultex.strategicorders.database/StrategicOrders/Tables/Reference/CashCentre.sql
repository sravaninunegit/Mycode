﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 18/10/2024
-- Description: Reference table of cash centres, shamelessly copied from settlement DB.
-- History: 18/10/2024 : Resource 503436 : SOTPT-726
-- ==================================================================
CREATE TABLE [Reference].[CashCentre](
	[CashCentreID]			BIGINT IDENTITY(1,1) NOT NULL,
	[CashCentreCode]		VARCHAR (50) NOT NULL,
	[CashCentreDescription] VARCHAR (100) NOT NULL,
	[CashCentreTypeCode]	VARCHAR (25) NOT NULL,
	[CreatedBy]				VARCHAR (50) NOT NULL,
	[CreatedOn]				DATETIME2 (7) NOT NULL,
	[UpdatedBy]				VARCHAR (50) NULL,
	[UpdatedOn]				DATETIME2 (7) NULL,
	[DeletedBy]				VARCHAR (50) NULL,
	[DeletedOn]				DATETIME2 (7) NULL,
	[RowLockVersion]		ROWVERSION,
	[IsActive]				BIT NOT NULL
    CONSTRAINT [PK_CashCentre] PRIMARY KEY CLUSTERED 
(
	[CashCentreID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_CashCentre] UNIQUE NONCLUSTERED 
(
	[CashCentreCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
