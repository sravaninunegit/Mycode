﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Reference].[QualityType] from org. domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Reference].[QualityType](
	[QualityTypeID] [BIGINT] IDENTITY(1,1) NOT NULL,
	[QualityTypeCode] [VARCHAR](50) NOT NULL,
	[QualityTypeDescription] [VARCHAR](100) NOT NULL,
	[CreatedBy] [VARCHAR](50) NOT NULL,
	[CreatedOn] [DATETIME2](7) NOT NULL,
	[UpdatedBy] [VARCHAR](50) NULL,
	[UpdatedOn] [DATETIME2](7) NULL,
	[DeletedBy] [VARCHAR](50) NULL,
	[DeletedOn] [DATETIME2](7) NULL,
	[RowLockVersion] [TIMESTAMP] NOT NULL,
	[IsActive] [BIT] NOT NULL,
	CONSTRAINT [PK_QualityType] PRIMARY KEY CLUSTERED 
	(
		[QualityTypeID] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
