﻿CREATE TABLE [Reference].[Media]
(
    [MediaID] [bigint] IDENTITY(1,1) NOT NULL,	
	[QualityID] [BIGINT] NOT NULL,
	[ProductCode] [varchar](50) NOT NULL,
	[SortingCode] [int] NOT NULL,
	[Currency] [varchar](50) NOT NULL,
	[Value] [numeric](10, 2) NOT NULL,
	[Package1] [int] NULL,
	[Package2] [int] NULL,
	[Package3] [int] NULL,	
	[CreatedBy] [varchar](100) NOT NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[UpdatedBy] [varchar](50) NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[DeletedBy] [varchar](50) NULL,
	[DeletedOn] [datetime2](7) NULL,
	[RowLockVersion] [timestamp] NOT NULL,
	[IsActive] [bit] NOT NULL,
	CONSTRAINT [PK_Media] PRIMARY KEY CLUSTERED 
	(
		[MediaID] ASC
	)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	CONSTRAINT [FK_Media_Quality] FOREIGN KEY([QualityID]) REFERENCES [Reference].[Quality] ([QualityID]),
	CONSTRAINT [UQ_ProductCode] UNIQUE NONCLUSTERED ([ProductCode])
) ON [PRIMARY]
GO
ALTER TABLE [Reference].[Media]
ADD CONSTRAINT [DF_Reference_Media_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Reference].[Media]
ADD CONSTRAINT [DF_Reference_Media_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Reference].[Media]
ADD CONSTRAINT [DF_Reference_Media_IsActive]
    DEFAULT (1) FOR [IsActive]
GO


