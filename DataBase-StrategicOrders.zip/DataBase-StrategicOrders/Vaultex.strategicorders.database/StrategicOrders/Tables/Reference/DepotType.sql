﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Carrier].[DepotType] from carrier domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Reference].[DepotType](
	[DepotTypeID] [BIGINT] IDENTITY(1,1) NOT NULL,
	[DepotTypeCode] [VARCHAR](3) NOT NULL,
	[DepotTypeDescription] [VARCHAR](100) NOT NULL,
	[CreatedBy] [VARCHAR](100) NOT NULL,
	[CreatedOn] [DATETIME2](7) NOT NULL,
	[UpdatedBy] [VARCHAR](100) NULL,
	[UpdatedOn] [DATETIME2](7) NULL,
	[DeletedBy] [VARCHAR](100) NULL,
	[DeletedOn] [DATETIME2](7) NULL,
	[RowLockVersion] [TIMESTAMP] NOT NULL,
	[IsActive] [BIT] NOT NULL,
    CONSTRAINT PK_DepotTypeID PRIMARY KEY CLUSTERED (DepotTypeID),
    CONSTRAINT UQ_DepotTypeCode  UNIQUE (DepotTypeCode)
);
