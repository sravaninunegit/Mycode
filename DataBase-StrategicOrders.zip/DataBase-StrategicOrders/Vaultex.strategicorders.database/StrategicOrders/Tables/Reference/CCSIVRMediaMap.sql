﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 31/10/2024
-- Description: Table mapping [Reference].[Media] product codes to IVR & CCS codes.
-- History: 31/10/2024 : Resource 503436 : SOTPT-848
-- ==================================================================
CREATE TABLE [Reference].[CCSIVRMediaMap] (
	[CCSIVRMediaMapID] BIGINT IDENTITY(1,1) NOT NULL,
	[ProductCode] VARCHAR(15) NOT NULL,
	[CCIVRCode] VARCHAR(10) NOT NULL,
	[CCSITIDCode] VARCHAR(5) NOT NULL,
	[CreatedBy] VARCHAR (100) NOT NULL,
	[CreatedOn] DATETIME2 (7) NOT NULL,
	[UpdatedBy] VARCHAR (100) NULL,
	[UpdatedOn] DATETIME2 (7) NULL,
	[DeletedBy] VARCHAR (100) NULL,
	[DeletedOn] DATETIME2 (7) NULL,
	[RowLockVersion] ROWVERSION NOT NULL,
	[IsActive] BIT NOT NULL,
	CONSTRAINT [PK_CCSIVRMediaMapID] PRIMARY KEY CLUSTERED ([CCSIVRMediaMapID]),
	CONSTRAINT [UQ_CCSIVRMediaMap_ProductCode] UNIQUE NONCLUSTERED ([ProductCode]),
	CONSTRAINT [UQ_CCSIVRMediaMap_CCSITIDCode] UNIQUE NONCLUSTERED ([CCSITIDCode]),
	CONSTRAINT [UQ_CCSIVRMediaMap_CCIVRCode] UNIQUE NONCLUSTERED ([CCIVRCode])
)
