﻿CREATE TABLE [Reference].[OrderingDenominations]
(
    [DenominationId] BIGINT IDENTITY(1,1) NOT NULL,
    [Code] VARCHAR(13) NOT NULL,
    [Description] VARCHAR(20) NOT NULL,    
    [CreatedBy] VARCHAR(100) NOT NULL,
    [CreatedOn] DATETIME2(7) NOT NULL,
    [UpdatedBy] VARCHAR(100) NULL,
    [UpdatedOn] DATETIME2(7) NULL,
    [DeletedBy] VARCHAR(100) NULL,
    [DeletedOn] DATETIME2(7) NULL,
    [RowLockVersion] ROWVERSION NOT NULL,
    [IsActive] BIT NOT NULL,
    CONSTRAINT [PK_OrderingDenominations] PRIMARY KEY CLUSTERED ([DenominationId] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY], 
    CONSTRAINT [UQ_Code] UNIQUE ([Code])
) ON [PRIMARY]
GO

ALTER TABLE [Reference].[OrderingDenominations] 
ADD CONSTRAINT [DF_Reference_OrderingDenominations_CreatedOn] 
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [Reference].[OrderingDenominations]
ADD CONSTRAINT [DF_Reference_OrderingDenominations_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [Reference].[OrderingDenominations]
ADD CONSTRAINT [DF_Reference_OrderingDenominations_IsActive]
    DEFAULT (1) FOR [IsActive]
GO


