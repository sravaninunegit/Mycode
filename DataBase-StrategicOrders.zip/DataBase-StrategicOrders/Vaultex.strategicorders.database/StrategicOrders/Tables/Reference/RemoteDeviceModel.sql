﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Reference].[RemoteDeviceModel] from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Reference].[RemoteDeviceModel] (
    [RemoteDeviceModelID]          BIGINT        IDENTITY (1, 1) NOT NULL,
    [RemoteDeviceManufacturerID]   BIGINT        NOT NULL,
    [RemoteDeviceModelCode]        VARCHAR (50)  NOT NULL,
    [RemoteDeviceModelDescription] VARCHAR (100) NOT NULL,
    [CreatedBy]                    VARCHAR (100)  NOT NULL,
    [CreatedOn]                    DATETIME2 (7) NOT NULL,
    [UpdatedBy]                    VARCHAR (100)  NULL,
    [UpdatedOn]                    DATETIME2 (7) NULL,
    [DeletedBy]                    VARCHAR (100)  NULL,
    [DeletedOn]                    DATETIME2 (7) NULL,
    [RowLockVersion]               ROWVERSION    NOT NULL,
    [IsActive]                     BIT           NOT NULL,
    CONSTRAINT [PK_RemotveDeviceModel] PRIMARY KEY CLUSTERED ([RemoteDeviceModelID] ASC),
    CONSTRAINT [FK_RemoteDeviceManufacturer_RemoteDeviceModel] FOREIGN KEY ([RemoteDeviceManufacturerID]) REFERENCES [Reference].[RemoteDeviceManufacturer] ([RemoteDeviceManufacturerID]),
    CONSTRAINT [UQ_RemotveDeviceModel] UNIQUE NONCLUSTERED ([RemoteDeviceModelCode], [RemoteDeviceManufacturerID] ASC)
);
