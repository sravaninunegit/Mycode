﻿CREATE TABLE [Reference].[OrderSource]
(
    [OrderSourceId] BIGINT IDENTITY(1, 1) NOT NULL,
	[OrderSourceCode] VARCHAR(50) NOT NULL, -- (WEB, MANUAL, FILE, IVR)    
    [OrderSourceDescription] VARCHAR(50) NOT NULL,
    [CreatedBy] VARCHAR(100) NOT NULL, 
    [CreatedOn] DATETIME2(7) NOT NULL,
    [UpdatedBy] VARCHAR(100) NULL,
    [UpdatedOn] DATETIME2(7) NULL,
    [DeletedBy] VARCHAR(100) NULL,
    [DeletedOn] DATETIME2(7) NULL,
    [RowLockVersion] ROWVERSION NOT NULL,
    [IsActive] BIT NOT NULL,    
    CONSTRAINT [PK_OrderSource] PRIMARY KEY CLUSTERED ([OrderSourceId] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [Reference].[OrderSource]
ADD CONSTRAINT [DF_Orders_OrderSource_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO
ALTER TABLE [Reference].[OrderSource]
ADD CONSTRAINT [DF_Orders_OrderSource_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
