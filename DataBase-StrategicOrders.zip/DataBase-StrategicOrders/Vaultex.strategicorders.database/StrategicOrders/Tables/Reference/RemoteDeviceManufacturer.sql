﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Reference].[RemoteDeviceManufacturer] from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Reference].[RemoteDeviceManufacturer] (
    [RemoteDeviceManufacturerID]          BIGINT        IDENTITY (1, 1) NOT NULL,
    [RemoteDeviceManufacturerCode]        VARCHAR (50)  NOT NULL,
    [RemoteDeviceManufacturerDescription] VARCHAR (100) NOT NULL,
    [CreatedBy]                           VARCHAR (100)  NOT NULL,
    [CreatedOn]                           DATETIME2 (7) NOT NULL,
    [UpdatedBy]                           VARCHAR (100)  NULL,
    [UpdatedOn]                           DATETIME2 (7) NULL,
    [DeletedBy]                           VARCHAR (100)  NULL,
    [DeletedOn]                           DATETIME2 (7) NULL,
    [RowLockVersion]                      ROWVERSION    NOT NULL,
    [IsActive]                            BIT           NOT NULL,
    CONSTRAINT [PK_RemoteDeviceManufacturer] PRIMARY KEY CLUSTERED ([RemoteDeviceManufacturerID] ASC),
    CONSTRAINT [UQ_RemoteDeviceManufacturer] UNIQUE NONCLUSTERED ([RemoteDeviceManufacturerCode] ASC)
);
