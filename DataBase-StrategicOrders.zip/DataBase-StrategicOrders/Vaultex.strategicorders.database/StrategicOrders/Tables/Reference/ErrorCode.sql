﻿CREATE TABLE [Reference].[ErrorCode](
	[ErrorCodeId] [BIGINT] IDENTITY(1,1) NOT NULL,
	[ErrorCode] [VARCHAR](7) NOT NULL,
	[ErrorDescription] [VARCHAR](255) NOT NULL,
	[CreatedBy] [VARCHAR](100) NOT NULL,
	[CreatedOn] [DATETIME2](7) NOT NULL,
	[UpdatedBy] [VARCHAR](100) NULL,
	[UpdatedOn] [DATETIME2](7) NULL,
	[DeletedBy] [VARCHAR](100) NULL,
	[DeletedOn] [DATETIME2](7) NULL,

	--todo: get unique into error code CONSTRAINT AK_TransactionID UNIQUE(TransactionID)
	[RowLockVersion] [TIMESTAMP] NOT NULL,
	[IsActive] [BIT] NOT NULL,
 CONSTRAINT [PK_ErrorCodeId] PRIMARY KEY CLUSTERED 
(
	[ErrorCodeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
