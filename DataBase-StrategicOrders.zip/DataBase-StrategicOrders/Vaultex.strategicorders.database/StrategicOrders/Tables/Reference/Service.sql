﻿CREATE TABLE [Reference].[Service](
	[ServiceID] [bigint] IDENTITY(1,1) NOT NULL,
	[ServiceTypeID] [bigint] NOT NULL,
	[ServiceCode] [varchar](50) NOT NULL,
	[ServiceDescription] [varchar](100) NOT NULL,
	[CreatedBy] [varchar](100) NOT NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[UpdatedBy] [varchar](100) NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[DeletedBy] [varchar](100) NULL,
	[DeletedOn] [datetime2](7) NULL,
	[RowLockVersion] [timestamp] NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_Service] PRIMARY KEY CLUSTERED 
(
	[ServiceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Service] UNIQUE NONCLUSTERED 
(
	[ServiceCode] ASC,
	[ServiceTypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Reference].[Service]  WITH CHECK ADD  CONSTRAINT [FK_ServiceType_Service] FOREIGN KEY([ServiceTypeID])
REFERENCES [Reference].[ServiceType] ([ServiceTypeID])
GO

ALTER TABLE [Reference].[Service] CHECK CONSTRAINT [FK_ServiceType_Service]
GO