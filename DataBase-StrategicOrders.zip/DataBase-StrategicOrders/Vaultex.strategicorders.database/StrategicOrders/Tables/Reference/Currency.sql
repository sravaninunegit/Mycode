﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Reference].[Currency] from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Reference].[Currency] (
    [CurrencyID]          BIGINT        IDENTITY (1, 1) NOT NULL,
    [CurrencyCode]        VARCHAR (50)  NOT NULL,
    [CurrencyDescription] VARCHAR (100) NOT NULL,
    [CreatedBy]           VARCHAR (100)  NOT NULL,
    [CreatedOn]           DATETIME2 (7) NOT NULL,
    [UpdatedBy]           VARCHAR (100)  NULL,
    [UpdatedOn]           DATETIME2 (7) NULL,
    [DeletedBy]           VARCHAR (100)  NULL,
    [DeletedOn]           DATETIME2 (7) NULL,
    [RowLockVersion]      ROWVERSION    NOT NULL,
    [IsActive]            BIT           NOT NULL,
    CONSTRAINT [PK_Currency] PRIMARY KEY CLUSTERED ([CurrencyID] ASC),
    CONSTRAINT [UQ_Currency] UNIQUE NONCLUSTERED ([CurrencyCode] ASC)
);
