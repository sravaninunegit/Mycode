﻿CREATE TABLE [Reference].[CashProcessingRule] (
    [CashProcessingRuleID]          BIGINT        IDENTITY (1, 1) NOT NULL,
    [CashProcessingRuleCode]        VARCHAR (50)  NOT NULL,
    [CashProcessingRuleDescription] VARCHAR (100) NOT NULL,
    [CreatedBy]                     VARCHAR (100)  NOT NULL,
    [CreatedOn]                     DATETIME2 (7) NOT NULL,
    [UpdatedBy]                     VARCHAR (100)  NULL,
    [UpdatedOn]                     DATETIME2 (7) NULL,
    [DeletedBy]                     VARCHAR (100)  NULL,
    [DeletedOn]                     DATETIME2 (7) NULL,
    [IsActive]                      BIT           NOT NULL,
    [RowLockVersion]                ROWVERSION    NOT NULL,
    CONSTRAINT [PK_CashProcessingRule] PRIMARY KEY CLUSTERED ([CashProcessingRuleID] ASC),
    CONSTRAINT [UQ_CashProcessingRule] UNIQUE NONCLUSTERED ([CashProcessingRuleCode] ASC)
);