﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Reference].[CassetteType] from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Reference].[CassetteType] (
    [CassetteTypeID]          BIGINT        IDENTITY (1, 1) NOT NULL,
    [CassetteTypeCode]        VARCHAR (50)  NOT NULL,
    [CassetteTypeDescription] VARCHAR (100) NOT NULL,
    [CreatedBy]               VARCHAR (100)  NOT NULL,
    [CreatedOn]               DATETIME2 (7) NOT NULL,
    [UpdatedBy]               VARCHAR (100)  NULL,
    [UpdatedOn]               DATETIME2 (7) NULL,
    [DeletedBy]               VARCHAR (100)  NULL,
    [DeletedOn]               DATETIME2 (7) NULL,
    [RowLockVersion]          ROWVERSION    NOT NULL,
    [IsActive]                BIT           NOT NULL,
    CONSTRAINT [PK_CassetteType] PRIMARY KEY CLUSTERED ([CassetteTypeID] ASC),
    CONSTRAINT [UQ_CassetteType] UNIQUE NONCLUSTERED ([CassetteTypeCode] ASC)
);

