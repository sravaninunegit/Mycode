﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Reference].[Quality] from org. domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Reference].[Quality](
	[QualityID] [BIGINT] IDENTITY(1,1) NOT NULL,
	[QualityTypeID] [BIGINT] NOT NULL,
	[QualityCode] [VARCHAR](3) NOT NULL,
	[QualityDescription] [VARCHAR](100) NOT NULL,
	[CreatedBy] [VARCHAR](50) NOT NULL,
	[CreatedOn] [DATETIME2](7) NOT NULL,
	[UpdatedBy] [VARCHAR](50) NULL,
	[UpdatedOn] [DATETIME2](7) NULL,
	[DeletedBy] [VARCHAR](50) NULL,
	[DeletedOn] [DATETIME2](7) NULL,
	[RowLockVersion] [TIMESTAMP] NOT NULL,
	[IsActive] [BIT] NOT NULL,
	CONSTRAINT [PK_Quality] PRIMARY KEY CLUSTERED 
	(
		[QualityID] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	CONSTRAINT [FK_Quality_QualityType] FOREIGN KEY([QualityTypeID]) REFERENCES [Reference].[QualityType] ([QualityTypeID])

) ON [PRIMARY]

