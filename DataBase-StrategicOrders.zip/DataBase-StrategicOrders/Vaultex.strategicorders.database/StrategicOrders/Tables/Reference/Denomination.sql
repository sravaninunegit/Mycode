﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Copy of [Reference].[Denomination] from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
CREATE TABLE [Reference].[Denomination] (
    [DenominationID]          BIGINT        IDENTITY (1, 1) NOT NULL,
    [DenominationCode]        VARCHAR (50)  NOT NULL,
    [DenominationDescription] VARCHAR (100) NOT NULL,
    [DenominationValue]       INT           NOT NULL,
    [DenominationType]        CHAR (4)      NULL,
    [CreatedBy]               VARCHAR (100)  NOT NULL,
    [CreatedOn]               DATETIME2 (7) NOT NULL,
    [UpdatedBy]               VARCHAR (100)  NULL,
    [UpdatedOn]               DATETIME2 (7) NULL,
    [DeletedBy]               VARCHAR (100)  NULL,
    [DeletedOn]               DATETIME2 (7) NULL,
    [RowLockVersion]          ROWVERSION    NOT NULL,
    [IsActive]                BIT           NOT NULL,
    CONSTRAINT [PK_Denomination] PRIMARY KEY CLUSTERED ([DenominationID] ASC),
    CONSTRAINT [UQ_Denomination] UNIQUE NONCLUSTERED ([DenominationCode] ASC)
);

