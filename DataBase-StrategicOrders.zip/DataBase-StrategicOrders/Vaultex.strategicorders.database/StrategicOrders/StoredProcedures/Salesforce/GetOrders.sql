﻿-- ==================================================================
-- Author:      Resource 504278
-- Create Date: 08/11/2024
-- History: 15/10/2024 : Resource 504278 : SOTPT-678
-- ==================================================================
CREATE PROCEDURE [Salesforce].[GetOrders]
(   	
	@AuditLogId BIGINT
)
AS
BEGIN
		SELECT so.OrderId as External_Id,
			   'ORDER' as Message_Type,
				(SELECT st.ServiceTypeCode as [inboundOrderMessage.serviceTypeCode]
				   , 'CO' as [inboundOrderMessage.serviceCode]
				   , 'IVR' as [inboundOrderMessage.orderType]
				   , 'Registered' as [inboundOrderMessage.orderStatus]
				   , o.OrderValue as [inboundOrderMessage.orderValue]
				   , o.DeliveryDate as [inboundOrderMessage.deliveryDate]
				   , c.CustomerNumber as [inboundOrderMessage.customerNumber]
				   , cc.cashCentreCode as [inboundOrderMessage.cashCentreCode]
				   , o.CarrierRouteCode as [inboundOrderMessage.carrierRouteCode]
				   , o.CustomerReference as [inboundOrderMessage.customerReference]
				   , cc.CashCentreTypeCode as [inboundOrderMessage.outputTypeCode]	  
				   , (SELECT m.ProductCode as [productCode]
							,od.Amount as [amount]
							,m.[Value] as [value]
							,m.Package1 as [Package1]
							,m.Package2 as [Package2]
							,m.Package3 as [Package3]
					  FROM [Orders].[OrderDetail] od
						INNER JOIN [Reference].[Media] m ON od.MediaID = m.MediaID
					  WHERE od.OrderId = o.OrderId
					  FOR JSON PATH
					 ) as [inboundOrderMessage.inboundOrderItems]
				FROM [Orders].[Order] o
		   			   INNER JOIN [Customer].[Customer] c ON o.CustomerID = c.CustomerID
					   INNER JOIN [Reference].[CashCentre] cc ON o.CashCentreID = cc.CashCentreID
					   INNER JOIN [Customer].[ProductServiceCustomer] psc ON psc.CustomerID = c.CustomerID
					   INNER JOIN [Reference].[ProductService] ps ON ps.ProductServiceID = psc.ProductServiceID
					   INNER JOIN [Reference].[Product] p ON p.ProductID = ps.ProductID
					   INNER JOIN [Reference].[Service] s ON s.ServiceID = ps.ServiceID
					   INNER JOIN [Reference].[ServiceType] st ON s.ServiceTypeID = st.ServiceTypeID
				WHERE OrderId = so.OrderId
				FOR JSON PATH) as Payload
		FROM [Orders].[Order] so
		WHERE so.OrderId IN (
								SELECT DISTINCT o.OrderId 
								FROM [Orders].[Order] o
									INNER JOIN [Orders].[OrderDetail] od ON od.OrderId = o.OrderId	
								WHERE o.AuditLogId = @AuditLogId
							 )
END
GO

