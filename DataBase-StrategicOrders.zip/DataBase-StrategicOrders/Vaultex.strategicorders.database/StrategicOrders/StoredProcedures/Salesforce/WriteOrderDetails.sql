﻿-- ==================================================================
-- Author:      Resource 504278
-- Create Date: 15/10/2024
-- History: 15/10/2024 : Resource 504278 : SOTPT-708
-- History: 18/10/2024 : Resource 503436 : SOTPT-726
-- History: 06/11/2024 : Resource 504278 : SOTPT-766
-- ==================================================================
CREATE PROCEDURE [Salesforce].[WriteOrderDetails]
(
    @Details [Salesforce].[OrderItem] READONLY
)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION [Tran1]

        INSERT INTO [Orders].[OrderDetail]
           ([MediaID],
			[OrderId],
            [Quantity],
            [Amount])
        SELECT            
            (SELECT [MediaID] FROM [Reference].[Media] m WHERE m.[ProductCode] = d.ProductCode),
            (SELECT OrderId FROM [Orders].[Order] o WHERE o.[SaleforceOrderId] = d.OrderId),                    
            Quantity,
            TotalPrice
        FROM @Details d

        COMMIT TRANSACTION [Tran1]
    END TRY

    BEGIN CATCH
        ROLLBACK TRANSACTION [Tran1];
        THROW
    END CATCH

END
GO
