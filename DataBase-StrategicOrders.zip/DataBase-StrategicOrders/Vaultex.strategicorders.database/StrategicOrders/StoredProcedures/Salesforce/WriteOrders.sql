﻿-- ==================================================================
-- Author:      Resource 504278
-- Create Date: 15/10/2024
-- History: 15/10/2024 : Resource 504278 : SOTPT-708
-- History: 17/10/2024 : Resource 503436 : SOTPT-776
-- History: 18/10/2024 : Resource 503436 : SOTPT-726
-- History: 06/11/2024 : Resource 504278 : SOTPT-766
-- History:14/11/2024 : Resource 504141 : SOTPT-802
-- History: 11/11/2024 : Resource 504141 : SOTPT-896

-- ==================================================================
CREATE PROCEDURE [Salesforce].[WriteOrders]
(   	
	@Orders [Salesforce].[Order] READONLY,
	@PipelineId UNIQUEIDENTIFIER,
	@PipelineName NVARCHAR(100)
)
AS
BEGIN
	BEGIN TRY
        BEGIN TRANSACTION [Tran1]        
			DECLARE @TempAuditIds TABLE (AuditId BIGINT)
			DECLARE @NumValidOrders INT
			DECLARE @NumInvalidOrders INT
			DECLARE @AuditPK BIGINT

			-- todo: update counts properly when order validation ticket ready.
			SELECT @NumValidOrders=COUNT(*) FROM @Orders --WHERE InvalidOrder = 0
			--SELECT @NumInvalidOrders=COUNT(*) FROM @Orders WHERE InvalidOrder = 1
			SET @NumInvalidOrders=0

			INSERT INTO [Audit].[DataLoadHistory]
				([filename]
				,[DateTimeReceived]
				,[PipelineName] -- todo: What is this?
				,[PipelineRunID] -- todo: What is this?
				,[Status] -- todo: What is this?
				,[ConfirmationNotification] -- todo: What is this?
				,[RejectionNotification] -- todo: What is this?
				,[ActionTaken] -- todo: What is this?
				,[TotalNoOfOrders]
				,[TotalNoOfValidOrders]
				,[TotalNoOfRejectedOrders]
				,[StartTime] -- todo: Start time of what?
				,[EndTime] -- todo: End time of what?
				,[OrderSourceId]
				,[IsActive])
			OUTPUT Inserted.AuditLogId INTO @TempAuditIds
			VALUES
				('RetrieveIVROrdersFromSalesforce'
				,GETDATE()
				,@PipelineName
				,@PipelineId
				,'Completed'
				,'??' -- todo: What is this?
				,'??' -- todo: What is this?
				,'??' -- todo: What is this?
				,@NumValidOrders + @NumInvalidOrders
				,@NumValidOrders
				,@NumInvalidOrders
				,'1800-01-01 00:00:00' -- todo: Start time of what?
				,'1800-01-01 00:00:00' -- todo: End time of what?
				,(SELECT [OrderSourceId] FROM [Reference].[OrderSource] WHERE [OrderSourceCode] = 'IVR')
				,1
				)

			SELECT @AuditPK = AuditId FROM @TempAuditIds;

			INSERT INTO [Orders].[Order]
					([AuditLogId]
					,[OrderType]
					,[LocationID]
					,[CustomerID]
					,[DeliveryDate]
					,[OrderValue]
					,[OrderDateTime]
					,[SaleforceOrderId]
					,[CustomerReference]
					,[CarrierRouteCode]					
					,[CashCentreID])
			SELECT	
					@AuditPK,
					LEFT(o.ServiceType, 1),
					NULL, -- Location not applicable to IVR.
					(SELECT [CustomerID] FROM [Customer].[Customer] WHERE [CustomerNumber] = o.CustomerNumber),
					o.DeliveryDate,
					o.TotalAmount,
					o.OrderDate,
					o.Id,
					o.CustomerReference,
					(SELECT CarrierRouteCode
					 FROM Customer.ProductServiceCustomerCarrier pscc
						INNER JOIN Customer.ProductServiceCustomer Psc on psc.ProductServiceCustomerID=pscc.ProductServiceCustomerID
						INNER JOIN Customer.Customer c on c.CustomerID=psc.CustomerID
						INNER JOIN [Reference].[ProductService] ON [ProductService].[ProductServiceID]=PSC.ProductServiceID
						INNER JOIN [Reference].[Product] ON [Product].[ProductID] =[ProductService].[ProductID]		
						INNER JOIN [Reference].[CashCentre]  ON [CashCentre].[CashCentreCode] = Psc.[CashCentreCode]
						INNER JOIN [Reference].[Service] ON [Service].[ServiceID]=[ProductService].[ServiceID] 
							AND [Product].ProductCode='OUT'
							AND [Service].[ServiceCode]='CO'
							AND [CustomerNumber] = o.CustomerNumber
							AND [CashCentreTypeCode] = o.ServiceType 
							AND [CashCentre].[IsActive] = 1
						INNER JOIN [Reference].[DayOfWeek] ON [DayOfWeek].[DayOfWeekID] = pscc.DayOfWeekID
					 WHERE [DayOfWeek].DayOfWeekDescription = DATENAME(DW, o.DeliveryDate) OR [DayOfWeek].DayOfWeekCode = 'ANY'),					
					(SELECT [CashCentreID] FROM [Customer].[Customer]
						INNER JOIN [Customer].[ProductServiceCustomer] ON [ProductServiceCustomer].[CustomerID] = [Customer].[CustomerID]
						INNER JOIN [Reference].[CashCentre] ON [CashCentre].[CashCentreCode] = [ProductServiceCustomer].[CashCentreCode]
						INNER JOIN [Reference].[ProductService] ON [ProductService].[ProductServiceID]=[ProductServiceCustomer].[ProductServiceID]
						INNER JOIN [Reference].[Product] ON [Product].[ProductID] =[ProductService].[ProductID]
						INNER JOIN [Reference].[Service] ON [Service].[ServiceID]=[ProductService].[ServiceID]
							AND [Product].ProductCode='OUT' 
							AND [Service].[ServiceCode]='CO'
					 WHERE [CustomerNumber] = o.CustomerNumber AND [CashCentreTypeCode] = o.ServiceType AND [CashCentre].[IsActive] = 1)
			FROM @Orders o

        COMMIT TRANSACTION [Tran1]
    END TRY

	BEGIN CATCH
        ROLLBACK TRANSACTION [Tran1];
        THROW
    END CATCH
END
GO

