﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 08/08/2024
-- Description: Returns true if file already imported.
-- History: 08/08/2024 : Resource 503436 : SOTPT-264
-- ==================================================================
CREATE PROCEDURE [Audit].[FileNameAlreadyExists]
(
    @FileName VARCHAR(100)
)
AS
BEGIN
	DECLARE @count BIGINT
	SELECT COUNT(*) FROM [Audit].[DataLoadHistory] WHERE [filename]=@FileName and [IsActive]=1
	RETURN IIF(@count>=1, 1,0)
END
GO
