﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 20/11/2024
-- Description: Return ICOREX filenames that would cause validation error FRJ004
-- History: 20/11/2024 : Resource 503436 : SOTPT-840
-- ==================================================================
CREATE PROCEDURE [ICOREX].[DupFileCheckFRJ004]
(
	@Seq INT,
	@FileDate DATE
)
AS
BEGIN
	SELECT [AuditLogId], [filename], CONVERT(DATE, SUBSTRING([filename], 12, 8), 112) 'Date', CAST(SUBSTRING([filename], 28, 6) AS INT) 'Seq' from [Audit].[DataLoadHistory]
	WHERE [filename] LIKE CONCAT('ICOREX_____________________', RIGHT(REPLICATE('0', 6) + CAST(@Seq AS VARCHAR(6)), 6), '.xml') AND CAST(SUBSTRING([filename], 28, 6) AS INT) = @Seq AND @FileDate < CONVERT(DATE, SUBSTRING([filename], 12, 8), 112)
END
