﻿-- ==================================================================
-- Author:      Resource 504278
-- Create Date: 04/11/2024
-- History: 04/11/2024 : Resource 504278 : SOTPT-776
-- ==================================================================
CREATE PROCEDURE [CallCentre].[GetOrders]
(
	@PipelineId uniqueidentifier
)
AS
BEGIN
	SELECT o.OrderType, c.CustomerNumber, o.DeliveryDate, '00' as uniqueid, o.OrderValue, '0' as serialno, 'IVR' as regOpnos, 
	   FORMAT(GETUTCDATE(), 'YYMMDDHHmmss') as regStamp, '0' as [state], 
	   (SELECT STRING_AGG(cimm.CCIVRCode + '=' + CAST(od.Amount as nvarchar),';')
		FROM [Orders].[OrderDetail] od
			INNER JOIN [Reference].[Media] m ON od.MediaID = m. MediaID
			INNER JOIN [Reference].[CCSIVRMediaMap] cimm ON m.ProductCode = cimm.ProductCode
		WHERE od.OrderId = o.OrderId) as cashSpec,
	    CONCAT(o.OrderType, c.CustomerNumber, o.DeliveryDate, '00') as primkey
	FROM [Orders].[Order] o
		INNER JOIN [Reference].[OutputType] t ON t.OutputTypeID = o.OutputTypeId
		INNER JOIN [Audit].[DataLoadHistory] l ON l.AuditLogId = o.AuditLogId
		INNER JOIN [Customer].[Customer] c ON c.CustomerID = o.CustomerID
	WHERE t.OutputTypeCode = 'CallCentre' AND l.[SalesforceBatchId] = @PipelineId
END
GO

