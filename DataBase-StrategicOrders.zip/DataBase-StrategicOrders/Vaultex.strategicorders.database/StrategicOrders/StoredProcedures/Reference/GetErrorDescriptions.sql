﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 08/08/2024
-- Description: Return error code descriptions.
-- History: 13/08/2024 : Resource 503436 : SOTPT-264
-- ==================================================================
CREATE PROCEDURE [Reference].[GetErrorDescriptions]
AS
BEGIN
	SELECT [ErrorCode], [ErrorDescription] FROM [Reference].[ErrorCode] WHERE [IsActive] = 1 ORDER BY [ErrorCode]
END
