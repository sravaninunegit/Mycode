﻿-- ==================================================================
-- Author:      Resource 504141
-- Create Date: 30/10/2024
-- History: 30/10/2024 : Resource 504141 : SOTPT-802
--updated on 07/11/2024 :Resource 504141 : SOTPT-802
-- ==================================================================
CREATE PROCEDURE [Reference].[usp_FillMediaData]
    @MediaData [Reference].[MediaData] READONLY
AS
BEGIN
    SET NOCOUNT ON;

    -- Merging data into Media table
    MERGE [Reference].[Media] AS T
    USING (
        SELECT Q.QualityID,
               M.ProductCode,
               M.SortingCode,
               M.Currency,
               M.Value,
               M.Package1,
               M.Package2,
               M.Package3
        FROM @MediaData M
        INNER JOIN [Reference].[Quality] Q ON Q.QualityCode = M.QualityCode
    ) AS S
    ON 
        T.ProductCode = S.ProductCode
    WHEN MATCHED THEN
        UPDATE SET T.QualityID = S.QualityID,
                   T.Value = S.Value,
                   T.SortingCode = S.SortingCode,
                   T.Currency = S.Currency,
                   T.Package1 = S.Package1,
                   T.Package2 = S.Package2,
                   T.Package3 = S.Package3,
                   T.CreatedBy = SYSTEM_USER,
                   T.CreatedOn = GETDATE()
    WHEN NOT MATCHED THEN
        INSERT (QualityID, ProductCode, SortingCode, Currency, Value, Package1, Package2, Package3, CreatedBy, CreatedOn)
        VALUES (S.QualityID, S.ProductCode, S.SortingCode, S.Currency, S.Value, S.Package1, S.Package2, S.Package3, SYSTEM_USER, GETDATE())
    WHEN NOT MATCHED BY SOURCE THEN
        DELETE;

END;
GO