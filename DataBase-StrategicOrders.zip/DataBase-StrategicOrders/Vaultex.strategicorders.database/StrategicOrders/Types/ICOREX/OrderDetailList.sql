﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 02/10/2024
-- Description: List of order details to ImPort.
-- History: 02/10/2024 : Resource 503436 : SOTPT-642
-- ==================================================================
CREATE TYPE [ICOREX].[OrderDetailList] AS TABLE
(
	OrderRowNo INT NOT NULL, -- For linking to back to order records in sproc
	ProductCode [VARCHAR](50) NOT NULL,
	Quantity BIGINT NOT NULL,
	Amount VARCHAR(19) NOT NULL
	-- todo: will need error data adding when validation rules ready.
)
