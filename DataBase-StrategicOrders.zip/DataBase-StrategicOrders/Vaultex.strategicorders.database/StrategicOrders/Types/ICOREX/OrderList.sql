﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 02/10/2024
-- Description: List of order to ImPort for ICOREX.
-- History: 02/10/2024 : Resource 503436 : SOTPT-642
-- History: 11/11/2024 : Resource 503436 : SOTPT-838
-- ==================================================================
CREATE TYPE [ICOREX].[OrderList] AS TABLE
(
	RowNo INT NOT NULL, -- For linking to details in sproc
	OrderDate DATE NOT NULL,
	DeliveryDate DATE NOT NULL,
	TotalValue VARCHAR(19) NOT NULL,
	CarrierRouteCode VARCHAR(12) NULL,
	CustomerReference VARCHAR(10) NULL,
	CustomerNumber VARCHAR(17) NOT NULL,
	InvalidOrder BIT NOT NULL,
	CommaSeparatedErrorCodes VARCHAR(160) NULL -- 20 errors max or NULL for no errors.
)

