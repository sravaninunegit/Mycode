﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 13/08/2024
-- Description: List of order to ImPort for CCORF.
-- History: 13/08/2024 : Resource 503436 : SOTPT-264
-- ==================================================================
CREATE TYPE [CCORF].[OrderList] AS TABLE
(
	RowNo INT NOT NULL, -- For linking to details in sproc
	LocationID VARCHAR(17) NOT NULL,
	OrderDate DATE NOT NULL,
	DeliveryDate DATE NOT NULL,
	TotalValue VARCHAR(19) NOT NULL,
	CarrierRouteCode VARCHAR(12) NULL,
	CustomerReference VARCHAR(10) NULL,
	OrderType CHAR(1) NOT NULL,
	RawOrderData TEXT NULL,
	InvalidOrder BIT NOT NULL,
	CommaSeparatedErrorCodes VARCHAR(100) NULL -- 20 errors max or NULL for no errors.
)

