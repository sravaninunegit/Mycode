﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 13/08/2024
-- Description: List of order details to ImPort.
-- History: 13/08/2024 : Resource 503436 : SOTPT-264
-- ==================================================================
CREATE TYPE [CCORF].[OrderDetailList] AS TABLE
(
	OrderRowNo INT NOT NULL, -- For linking to back to order records in sproc
	ProductCode [VARCHAR](50) NOT NULL,
	Quantity BIGINT NOT NULL,
	Amount VARCHAR(19) NOT NULL,
	ProductItemDetails CHAR(3) NOT NULL,
	RawOrderData TEXT NULL,
	CommaSeparatedErrorCodes VARCHAR(100) NULL -- 20 max or NULL for no errors.
)
