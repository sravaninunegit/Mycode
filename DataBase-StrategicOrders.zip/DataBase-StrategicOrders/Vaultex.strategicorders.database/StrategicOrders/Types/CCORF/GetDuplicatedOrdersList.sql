﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 22/08/2024
-- Description: List of orders to check for duplicates (order already is in existment).
-- History: 22/08/2024 : Resource 503436 : SOTPT-264
-- ==================================================================
CREATE TYPE [CCORF].[GetDuplicatedOrdersList] AS TABLE
(
	RowId INT NOT NULL,
	LocationId VARCHAR(17) NOT NULL,
	DeliveryDate DATE NOT NULL,
	OrderType CHAR(1) NOT NULL
)
