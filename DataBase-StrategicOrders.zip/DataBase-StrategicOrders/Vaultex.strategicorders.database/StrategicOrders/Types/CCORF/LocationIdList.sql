﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 20/08/2024
-- Description: List of CCORF location IDs.
-- History: 20/08/2024 : Resource 503436 : SOTPT-264
-- ==================================================================
CREATE TYPE [CCORF].[LocationIdList] AS TABLE
(
	LocationId VARCHAR(50) NOT NULL
)
