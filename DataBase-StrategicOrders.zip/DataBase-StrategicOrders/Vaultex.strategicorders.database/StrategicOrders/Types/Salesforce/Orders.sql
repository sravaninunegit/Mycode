﻿-- ==================================================================
-- Author:      Resource 504278
-- Create Date: 15/10/2024
-- Description: List of order to Import for Saleforce.
-- History: 15/10/2024 : Resource 504278 : SOTPT-708
-- ==================================================================

CREATE TYPE [Salesforce].[Order] AS TABLE(
	Id VARCHAR(18) NOT NULL, -- For linking to details in sproc
	ServiceType [varchar](4) NOT NULL,
	CustomerNumber VARCHAR(17) NOT NULL,
	CustomerReference VARCHAR(10) NULL,
	DeliveryDate DATE NOT NULL,
	TotalAmount DECIMAL(16, 2) NOT NULL,	
	OrderDate DATE NOT NULL
	-- todo: will need error data adding when validation rules ready.
)