﻿-- ==================================================================
-- Author:      Resource 504278
-- Create Date: 15/10/2024
-- Description: List of order itmes to Import from Saleforce.
-- History: 15/10/2024 : Resource 504278 : SOTPT-708
-- ==================================================================

CREATE TYPE [Salesforce].[OrderItem] AS TABLE
(
	Id VARCHAR(18) NOT NULL, -- For linking to back to order records in sproc
	OrderId VARCHAR(18) NOT NULL,
	ProductCode VARCHAR(12) NOT NULL,
	Service_Type VARCHAR(5) NOT NULL,
	Quantity BIGINT NOT NULL,
	TotalPrice decimal(16, 2) NOT NULL
	-- todo: will need error data adding when validation rules ready.
)