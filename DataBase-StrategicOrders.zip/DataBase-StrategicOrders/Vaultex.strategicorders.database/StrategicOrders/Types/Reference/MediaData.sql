﻿-- ==================================================================
-- Author:      Resource 504141
-- Create Date: 30/10/2024
-- History: 30/10/2024 : Resource 504141 : SOTPT-802
-- ==================================================================
CREATE TYPE [Reference].[MediaData] AS TABLE
(
	[QualityCode] [varchar](50) NOT NULL,
	[ProductCode] [varchar](50) NOT NULL,
	[SortingCode] [int] NOT NULL,
	[Currency] [varchar](50) NOT NULL,
	[Value] [numeric](10, 2) NOT NULL,
	[Package1] [int] NULL,
	[Package2] [int] NULL,
	[Package3] [int] NULL
)
