﻿

-- ==================================================================
-- Author:      Resource 504141
-- Create Date: 06/11/2024
-- History: 06/11/2024 : Resource 504141 : SOTPT-850
-- ==================================================================
CREATE TYPE [Orders].[CCSData] AS TABLE(
	[ordtype] [char](1) NULL,
	[lcuno] [char](17) NULL,
	[ddate] [char](8) NULL,
	[totval] [decimal](16, 2) NULL,
	[regStamp] [char](12) NULL,
	[centre] [char](4) NULL,
	[CDR] [char](17) NULL,	
	[cashSpec] varchar(max),
	[regOpnos] [char](7) NULL,
	[serialno] [char](18) NULL
)
