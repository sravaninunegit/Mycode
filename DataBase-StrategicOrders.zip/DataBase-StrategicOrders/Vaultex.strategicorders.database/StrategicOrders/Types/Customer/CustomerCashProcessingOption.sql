﻿CREATE TYPE [Customer].[CustomerCashProcessingOption] AS TABLE(
	[CustomerNumber] [varchar](17) NOT NULL,
	[CashProcessingOptionValue] [varchar](250) NOT NULL,
	[CashProcessingRuleID] [varchar](17) NOT NULL,
	[CashProcessingRuleCode] [varchar](50) NOT NULL,
	[ServiceTypeCode] [varchar](50) NOT NULL,
	[ServiceCode] [varchar](50) NOT NULL,
	[ProductCode] [varchar](50) NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[IsActive] [bit] NOT NULL
)
GO
