﻿-- ==================================================================
-- Author:      Resource 504141
-- Create Date: 30/10/2024
-- History: 30/10/2024 : Resource 504141 : SOTPT-802
-- ==================================================================
CREATE TYPE [Customer].[ProductServiceCustomerData] AS TABLE(
	[ServiceCode] [varchar](50) NOT NULL,
	[ProductCode] [varchar](50) NOT NULL,
	[ServiceTypeCode] [varchar](50) NOT NULL,
	[ClientCode] [varchar](63) NULL,
	[CustomerNumber] [varchar](50) NOT NULL,
	[CashCentreCode] [int] NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL
)