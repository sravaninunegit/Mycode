﻿-- ==================================================================
-- Author:      Resource 504141
-- Create Date: 30/10/2024
-- History: 30/10/2024 : Resource 504141 : SOTPT-802
-- ==================================================================
CREATE TYPE [Customer].[RemoteDeviceData] AS TABLE(
	[CustomerNumber] [varchar](50) NOT NULL,
	[RemoteDeviceModelCode] [varchar](50) NOT NULL,
	[RemoteDeviceManufacturerCode] [varchar](50) NOT NULL,
	[CassetteTypeCode] [varchar](50) NOT NULL,
	[IsDyeCassette] [bit] NOT NULL,
	[MaxNotes] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL
)
