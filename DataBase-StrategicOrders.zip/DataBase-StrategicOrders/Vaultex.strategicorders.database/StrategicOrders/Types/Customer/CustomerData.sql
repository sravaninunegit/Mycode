﻿CREATE TYPE [Customer].[CustomerData] AS TABLE
(
	[CustomerNumber]    VARCHAR (17)  NOT NULL,
    [CustomerName]      VARCHAR (50)  NOT NULL, 
    [CustomerStatusCode] [varchar](50) NOT NULL,
    [CreditLimit]       BIGINT        NULL,
    [IsActive] [bit] NOT NULL
)
