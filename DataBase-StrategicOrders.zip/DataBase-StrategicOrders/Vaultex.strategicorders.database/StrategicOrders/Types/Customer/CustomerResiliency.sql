﻿CREATE TYPE [Customer].[CustomerResiliency] AS TABLE
(
	[OrganisationName] [varchar](50) NOT NULL,
	[CustomerLocationID]		VARCHAR(50)		NOT NULL,
	[CustomerNumber]			VARCHAR(20)		NOT NULL
)
