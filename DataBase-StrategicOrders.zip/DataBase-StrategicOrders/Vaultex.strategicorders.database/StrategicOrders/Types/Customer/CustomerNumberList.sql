﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: List of customer numbers
-- History: 07/11/2024 : Resource 503436 : SOTPT-838
-- ==================================================================
CREATE TYPE [Customer].[CustomerNumberList] AS TABLE
(
	CustomerNumber VARCHAR(17) NOT NULL
)
