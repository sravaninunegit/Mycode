﻿
-- ==================================================================
-- Author:      Resource 504141
-- Create Date: 30/10/2024
-- History: 30/10/2024 : Resource 504141 : SOTPT-802
-- ==================================================================
CREATE TYPE [Customer].[CassetteData] AS TABLE(
	[CustomerNumber] [varchar](50) NOT NULL,
	[RemoteDeviceManufacturerCode] [varchar](50) NOT NULL,
	[RemoteDeviceModelCode] [varchar](50) NOT NULL,
	[DenominationCode] [varchar](50) NOT NULL,
	[IssuerCode] [varchar](50) NOT NULL,
	[CurrencyCode] [varchar](50) NOT NULL,
	[CassetteNumber] [varchar](50) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL
)