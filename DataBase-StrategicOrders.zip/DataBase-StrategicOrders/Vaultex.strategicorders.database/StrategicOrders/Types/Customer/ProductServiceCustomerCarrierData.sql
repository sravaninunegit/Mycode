﻿-- ==================================================================
-- Author:      Resource 504141
-- Create Date: 30/10/2024
-- History: 30/10/2024 : Resource 504141 : SOTPT-802
-- ==================================================================
CREATE TYPE [Customer].[ProductServiceCustomerCarrierData] AS TABLE
(   [CustomerNumber]			VARCHAR(50)		NOT NULL,
	[CarrierRouteCode]			VARCHAR(50)		NOT NULL,
	[DayOfWeekCode] [varchar](50) NOT NULL,	
	[ServiceTypeCode] [varchar](50) NOT NULL,
	[ProductCode] [varchar](50) NOT NULL,
	[ServiceCode] [varchar](50) NOT NULL,	
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL
)
