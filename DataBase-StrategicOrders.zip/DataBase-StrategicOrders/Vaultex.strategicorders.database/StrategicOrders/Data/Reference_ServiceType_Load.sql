﻿IF NOT EXISTS (SELECT NULL FROM Reference.ServiceType WHERE ServiceTypeId = -1)
BEGIN
    SET IDENTITY_INSERT Reference.ServiceType ON;
    INSERT INTO Reference.ServiceType (
        ServiceTypeID, 
        ServiceTypeCode, 
        ServiceTypeDescription, 
        CreatedBy, 
        CreatedOn,
        UpdatedBy, 
        UpdatedOn,
        IsActive
    )
    VALUES (
        -1, 
        'UNK', 
        'Unknown', 
        SYSTEM_USER, 
        SYSDATETIME(),
        SYSTEM_USER, 
        SYSDATETIME(),
        1
    )     
    SET IDENTITY_INSERT Reference.ServiceType OFF;
END
MERGE INTO Reference.ServiceType AS t
USING
    (
    SELECT
        s.ServiceTypeCode, 
        s.ServiceTypeDescription, 
        s.CreatedBy, 
        s.CreatedOn, 
        s.IsActive
    FROM
    (
    VALUES
        (1, 'COIN', 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        (2, 'NOTE', 'Note', SYSTEM_USER, SYSDATETIME(), 1)
    ) s (ServiceTypeID, ServiceTypeCode, ServiceTypeDescription, CreatedBy, CreatedOn, IsActive)
    ) AS s
ON t.ServiceTypeCode = s.ServiceTypeCode
WHEN MATCHED AND (
                 t.ServiceTypeDescription <> s.ServiceTypeDescription
                 OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET
        t.ServiceTypeDescription = s.ServiceTypeDescription,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT (
        ServiceTypeCode, 
        ServiceTypeDescription, 
        CreatedBy, 
        CreatedOn,
        UpdatedBy, 
        UpdatedOn,
        IsActive
    )
    VALUES (
        s.ServiceTypeCode, 
        s.ServiceTypeDescription, 
        s.CreatedBy, 
        s.CreatedOn,
        s.CreatedBy, 
        s.CreatedOn,
        s.IsActive
    );


