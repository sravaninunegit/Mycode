﻿IF NOT EXISTS (SELECT NULL FROM Reference.CustomerStatus WHERE CustomerStatusId = -1)
BEGIN
    SET IDENTITY_INSERT Reference.CustomerStatus ON;
    INSERT INTO Reference.CustomerStatus (
        CustomerStatusId,
        CustomerStatusCode,
        CustomerStatusDescription,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
    )
    VALUES
     (-1, 'UNK', 'Unknown', SYSTEM_USER, SYSDATETIME(), SYSTEM_USER, SYSDATETIME(), 1)
    SET IDENTITY_INSERT Reference.CustomerStatus OFF;
END
MERGE INTO Reference.CustomerStatus AS t
USING
(SELECT
    s.CustomerStatusCode,
    s.CustomerStatusDescription,
    s.CreatedBy,
    s.CreatedOn,
    s.IsActive
 FROM
(VALUES
     ('Active', 'Active', SYSTEM_USER, SYSDATETIME(), 1),
     ('Inactive', 'Inactive', SYSTEM_USER, SYSDATETIME(), 1)
   ) s (CustomerStatusCode, CustomerStatusDescription, CreatedBy, CreatedOn, IsActive) ) AS s
ON t.CustomerStatusCode = s.CustomerStatusCode
WHEN MATCHED AND (t.CustomerStatusDescription <> s.CustomerStatusDescription
                 OR t.IsActive <> s.IsActive) THEN
    UPDATE SET
        t.CustomerStatusCode = s.CustomerStatusCode,
        t.CustomerStatusDescription = s.CustomerStatusDescription,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT (
        CustomerStatusCode,
        CustomerStatusDescription,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
    )
    VALUES (
        s.CustomerStatusCode,
        s.CustomerStatusDescription,
        s.CreatedBy,
        s.CreatedOn,
        s.CreatedBy,
        s.CreatedOn,
        s.IsActive
   );

