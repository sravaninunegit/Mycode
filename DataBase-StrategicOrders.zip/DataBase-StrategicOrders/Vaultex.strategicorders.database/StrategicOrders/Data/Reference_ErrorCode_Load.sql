﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 13/08/2024
-- Description: Upset error codes
-- History: 13/08/2024 : Resource 503436 : SOTPT-264
-- History: 29/10/2024 : Resource 503436 : SOTPT-832 Rename to match file naming convention.
-- ==================================================================
BEGIN
MERGE INTO [Reference].[ErrorCode] AS t
USING
    (
	    SELECT
        o.[ErrorCode],
        o.[ErrorDescription],       
        o.[CreatedBy]
    FROM
    (
    VALUES       
	   ('1010','Customer Number on the file name is invalid.','DB'),
	   ('1012','Customer Number on file header do not match the Customer Number on file name.','DB'),
	   ('1013','Header date does not match the date in file name.','DB'),
	   ('1014','Duplicate File Name.','DB'),
	   ('1020','The Location Number is invalid.','DB'),
	   ('1024','File Name should be CCORF_000000000XXXXXXXX_YYYYMMDDHHMMSS','DB'),
	   ('1026','Header record total has invalid characters','DB'),
	   ('1027','Empty or Invalid import record length.','DB'),
	   ('1028','Header total do not match the sum of details total.','DB'),
	   ('2021','Order date is past date','DB'),
	   ('2030','Amount is not a multiple of the strap value.','DB'),
	   ('2031','Amount is not a multiple of the denomination.','DB'),
	   ('2040','The total of all the order amounts already stored and the total order amounts in the CCORF is greater than the Customer Credit Limit.','DB'),
	   ('2069','Order already exists.','DB'),
	   ('2090','Schedule does not exist','DB'),
	   ('3020','The Product Unit Details is invalid.','DB'),
	   ('5010','Van Allocated for Delivery is not Valid','DB'),
	   ('5020','Customer Order reference missing','DB'),
	   ('9005','Trailer record count has invalid characters.','DB'),
	   ('9009','Duplicate Trailer record in file.','DB'),
	   ('9010','The number of records value in the trailer record does not match the total number of 02, 21, records.','DB'),
	   ('9020','The total value amount in the trailer record does not match the sum of all 02 total value amounts.','DB'),
	   ('9998','Order date is too far in the future','DB'),
	   ('9999','Unknown Error, Please Check log for details.','DB'),
	   ('FRJ001','File already processed.','DB'),
	   ('FRJ002','File failed validation.','DB'),
	   ('FRJ003','Filename format incorrect.','DB'),
	   ('FRJ004','File creation date out of range','DB'),
	   ('CUS0001','Customer Number not found','DB'),
	   ('CUS0002','Customer is inactive','DB'),
	   ('CUS0003','Customer is not setup for note out service','DB'),
	   ('CUS0004','Customer not setup for coin out service','DB'),
	   ('CUS0005','Customer does not have a carrier for note out scheduled','DB'),
	   ('CUS0006','Customer does not have a carrier for coin out scheduled','DB'),
	   ('CUS0007','Assigned centre for NOTE out is unknown or inactive','DB'),
	   ('ORD0001','Delivery date is in the past','DB'),
	   ('ORD0002','Delivery date is more than 30 days in the future','DB'),
	   ('ORD0003','Fulfilment date is in the past','DB'),
	   ('ORD0004','Fulfilment date is more than 30 days in the future','DB')
    ) o ([ErrorCode],[ErrorDescription],[CreatedBy])
    ) AS o
ON t.[ErrorCode] = o.[ErrorCode]
WHEN MATCHED AND (t.[ErrorDescription] != o.[ErrorDescription]) THEN
    UPDATE SET
        t.[ErrorCode] = o.[ErrorCode],
        t.[ErrorDescription] = o.[ErrorDescription],
        t.[UpdatedBy] = o.[CreatedBy],
		t.[UpdatedOn] = GETDATE()
WHEN NOT MATCHED THEN
    INSERT (
        [ErrorCode],
        [ErrorDescription],        
        [CreatedBy],
		[CreatedOn],
		[IsActive]
       )
    VALUES (
        o.[ErrorCode],
        o.[ErrorDescription],        
        o.[CreatedBy],
		GETDATE(),
		1
    );
END

