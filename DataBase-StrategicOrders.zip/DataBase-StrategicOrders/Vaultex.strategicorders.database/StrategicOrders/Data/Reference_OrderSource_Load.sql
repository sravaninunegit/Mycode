﻿BEGIN 
-- Merge new data
MERGE INTO [Reference].[OrderSource] AS t
USING
    (
    SELECT
        o.OrderSourceCode,
        o.OrderSourceDescription,       
        o.CreatedBy
    FROM
    (
    VALUES       
       ('WEB', 'Web orders', 'DB'),
       ('IVR', 'Phone orders', 'DB'),
       ('Manual', 'Manual orders', 'DB'),
       ('BRCCORF', 'Barclays resilience orders via CCORF', 'DB'),
       ('CCORF', 'CCORF orders', 'DB'),
       ('ICOREX', 'ICOREX orders', 'DB'),
       ('ORF', 'ORF orders', 'DB')
    ) o (OrderSourceCode,OrderSourceDescription,CreatedBy)
    ) AS o
ON t.OrderSourceCode = o.OrderSourceCode
WHEN MATCHED THEN
    UPDATE SET
        t.OrderSourceDescription = o.OrderSourceDescription,     
        t.CreatedBy = o.CreatedBy,
        t.UpdatedBy = o.CreatedBy
WHEN NOT MATCHED THEN
    INSERT (
        OrderSourceCode,
        OrderSourceDescription,        
        CreatedBy
       )
    VALUES (
        o.OrderSourceCode,
        o.OrderSourceDescription,        
        o.CreatedBy
    );
   END