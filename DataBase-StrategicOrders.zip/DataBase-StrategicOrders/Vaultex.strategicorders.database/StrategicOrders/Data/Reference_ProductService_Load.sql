﻿IF NOT EXISTS (SELECT NULL FROM Reference.ProductService WHERE ProductServiceId = -1)
BEGIN
    SET IDENTITY_INSERT Reference.ProductService ON;
    INSERT INTO Reference.ProductService (
        ProductServiceID, 
        ServiceID, 
        ProductID, 
        CreatedBy, 
        CreatedOn, 
        UpdatedBy, 
        UpdatedOn,
        IsActive
        )
    VALUES (-1, -1, -1, SYSTEM_USER, SYSDATETIME(), SYSTEM_USER, SYSDATETIME(), 1)
    SET IDENTITY_INSERT Reference.ProductService OFF;
END
MERGE INTO Reference.ProductService AS t
USING
    (
    SELECT
        se.ServiceId, p.ProductId, s.CreatedBy, s.CreatedOn, s.IsActive
    FROM
    (
    VALUES
        ('CRC', 'CI', 'COIN', SYSTEM_USER, SYSDATETIME(), 1),
        ('CRC', 'CI', 'NOTE', SYSTEM_USER, SYSDATETIME(), 1),
        ('PRC', 'CI', 'NOTE', SYSTEM_USER, SYSDATETIME(), 1),
        ('BPI', 'CI', 'NOTE', SYSTEM_USER, SYSDATETIME(), 1),
        ('BPI', 'CI', 'COIN', SYSTEM_USER, SYSDATETIME(), 1),
        ('DFC', 'CI', 'NOTE', SYSTEM_USER, SYSDATETIME(), 1),
        ('DFC', 'CI', 'COIN', SYSTEM_USER, SYSDATETIME(), 1),
        ('CBT', 'CI', 'COIN', SYSTEM_USER, SYSDATETIME(), 1),
        ('CBT', 'CI', 'NOTE', SYSTEM_USER, SYSDATETIME(), 1),
        ('BCS', 'CI', 'COIN', SYSTEM_USER, SYSDATETIME(), 1),
        ('BCS', 'CI', 'NOTE', SYSTEM_USER, SYSDATETIME(), 1),
        ('OUT', 'CO', 'COIN', SYSTEM_USER, SYSDATETIME(), 1),
        ('OUT', 'CO', 'NOTE', SYSTEM_USER, SYSDATETIME(), 1),
        ('OUT', 'CO', 'UNK', SYSTEM_USER, SYSDATETIME(), 1)

    ) s (ProductCode, ServiceCode, ServiceTypeCode, CreatedBy, CreatedOn, IsActive)
    LEFT OUTER JOIN Reference.ServiceType st
        ON s.ServiceTypeCode = st.ServiceTypeCode
    LEFT OUTER JOIN Reference.Service se
        ON s.ServiceCode = se.ServiceCOde AND st.ServiceTypeId = se.ServiceTypeId
    LEFT OUTER JOIN Reference.Product p
        ON s.ProductCode = p.ProductCode
    ) AS s
ON t.ServiceID = s.ServiceID AND t.ProductID = s.ProductID
WHEN MATCHED AND (t.IsActive <> s.IsActive) THEN
    UPDATE SET
       
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT
        (
        ServiceId, ProductID, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsActive
        )
    VALUES
        (s.ServiceId, s.ProductId, s.CreatedBy, s.CreatedOn, s.CreatedBy, s.CreatedOn, s.IsActive);


