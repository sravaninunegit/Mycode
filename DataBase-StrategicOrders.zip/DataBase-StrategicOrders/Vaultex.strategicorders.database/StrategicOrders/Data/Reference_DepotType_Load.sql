﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Populate [Reference].[DepotType] with business codes, copied from carrier domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
IF NOT EXISTS (SELECT NULL FROM Reference.DepotType WHERE DepotTypeID = -1)
BEGIN
    SET IDENTITY_INSERT Reference.DepotType ON;
    INSERT INTO Reference.DepotType (  
        DepotTypeID,
        DepotTypeCode,              
        DepotTypeDescription, 
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
        )
    VALUES (
        -1, 
        'UNK', 
        'Unknown', 
        'DB', 
        SYSDATETIME(), 
        'DB', 
        SYSDATETIME(),
        1
        )
    SET IDENTITY_INSERT Reference.DepotType OFF;
END;

MERGE INTO Reference.DepotType AS t
USING
(
SELECT
   s.DepotTypeCode,
   s.DepotTypeDescription,
   s.CreatedBy,
   s.CreatedOn,
   s.IsActive
FROM
(
VALUES
     ('REG', 'Regular', 'DB', SYSDATETIME(), 1),
     ('VCC', 'Virtual Cash Centre', 'DB', SYSDATETIME(), 1),
     ('CBT', 'Cash Bulk Till', 'DB', SYSDATETIME(), 1)
) s 
(DepotTypeCode, DepotTypeDescription, CreatedBy, CreatedOn, IsActive) ) AS s
ON t.DepotTypeCode = s.DepotTypeCode
WHEN MATCHED AND (t.DepotTypeDescription <> s.DepotTypeDescription
                 OR t.IsActive <> s.IsActive) THEN
    UPDATE SET
      t.DepotTypeDescription = s.DepotTypeDescription,
      t.UpdatedBy = s.CreatedBy,
      t.UpdatedOn = s.CreatedOn,
      t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
INSERT
    (  
    DepotTypeCode,
    DepotTypeDescription,
    CreatedBy,
    CreatedOn,
    UpdatedBy,
    UpdatedOn,
    IsActive
    )
VALUES
    (
     s.DepotTypeCode,
     s.DepotTypeDescription,
     s.CreatedBy,
     s.CreatedOn,
     s.CreatedBy,
     s.CreatedOn,
     s.IsActive
     );
