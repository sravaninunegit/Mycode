﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Populate [Reference].[CassetteType] with business codes, copied from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
IF NOT EXISTS (SELECT NULL FROM Reference.CassetteType WHERE CassetteTypeID = -1)
BEGIN
    SET IDENTITY_INSERT Reference.CassetteType ON;
    INSERT INTO Reference.CassetteType
    (
    CassetteTypeId,
    CassetteTypeCode,
    CassetteTypeDescription,
    CreatedBy,
    CreatedOn,
    UpdatedBy,
    UpdatedOn,
    IsActive
    )
    VALUES (-1, 'UNK', 'Unknown', SYSTEM_USER, SYSDATETIME(), SYSTEM_USER, SYSDATETIME(), 1)
    SET IDENTITY_INSERT Reference.CassetteType OFF;
END;
MERGE INTO Reference.CassetteType AS t
USING
(SELECT
    s.CassetteTypeCode,
    s.CassetteTypeDescription,
    s.CreatedBy,
    s.CreatedOn,
    s.IsActive
 FROM
(VALUES

   ('NCR01', 'NCRxx84', SYSTEM_USER, SYSDATETIME(), 1),
   ('DIE01', 'Diebold36xx', SYSTEM_USER, SYSDATETIME(), 1),
   ('DIE02', 'Diebold47xx', SYSTEM_USER, SYSDATETIME(), 1),
   ('DIE03', 'Diebold10xx', SYSTEM_USER, SYSDATETIME(), 1),
   ('DIE04', 'Diebold10xxD', SYSTEM_USER, SYSDATETIME(), 1),
   ('SIE01', 'Siemens21xx', SYSTEM_USER, SYSDATETIME(), 1),
   ('WIN01', 'Wincor/Nxdf STD ', SYSTEM_USER, SYSDATETIME(), 1),
   ('WIN02', '**DYE Wincor/Nxdf ', SYSTEM_USER, SYSDATETIME(), 1),
   ('TRI01', 'Triton', SYSTEM_USER, SYSDATETIME(), 1),
   ('NCR02', '**DYE NCRxx84 ', SYSTEM_USER, SYSDATETIME(), 1),
   ('WIN03', 'Wincor HDM STD', SYSTEM_USER, SYSDATETIME(), 1),
   ('WIN04', '**DYE Wincor HDM', SYSTEM_USER, SYSDATETIME(), 1),
   ('NCR03', 'NCR Fluiditi ', SYSTEM_USER, SYSDATETIME(), 1),
   ('HYO01', 'Minibank Hyosung', SYSTEM_USER, SYSDATETIME(), 1),
   ('HYO02', 'Nanocash Hyosung	', SYSTEM_USER, SYSDATETIME(), 1),
   ('CAR01', 'Cardtronics S2 NCR', SYSTEM_USER, SYSDATETIME(), 1),
   ('CAR02', 'Cardtronics NCRxx84', SYSTEM_USER, SYSDATETIME(), 1),
   ('CAR03', '**Cardtronics DYE NCRxx84', SYSTEM_USER, SYSDATETIME(), 1),
   ('CAR04', 'Cardtronics Wincor/Nxdf STD', SYSTEM_USER, SYSDATETIME(), 1),
   ('CAR05', '**Cardtronics DYE Wincor/Nxdf', SYSTEM_USER, SYSDATETIME(), 1),
   ('CAR06', 'Cardtronics Wincor HDM STD', SYSTEM_USER, SYSDATETIME(), 1), 
   ('CAR07', '**Cardtronics DYE Wincor HDM', SYSTEM_USER, SYSDATETIME(), 1), 
   ('CAR08', 'Cardtronics Triton', SYSTEM_USER, SYSDATETIME(), 1),
   ('CAR09', 'Cardtronics Minibank Hyosung', SYSTEM_USER, SYSDATETIME(), 1),
   ('CAR10', 'Cardtronics Nanocash Hyosung', SYSTEM_USER, SYSDATETIME(), 1),
   ('NCR04', 'NCR 6623 S2', SYSTEM_USER, SYSDATETIME(), 1),
   ('NCR05', 'NCR 6684 S2', SYSTEM_USER, SYSDATETIME(), 1)
   ) s (CassetteTypeCode, CassetteTypeDescription, CreatedBy, CreatedOn, IsActive) ) AS s
ON t.CassetteTypeCode = s.CassetteTypeCode
WHEN MATCHED AND (t.CassetteTypeDescription <> s.CassetteTypeDescription
                 OR t.IsActive <> s.IsActive) THEN
    UPDATE SET
        t.CassetteTypeDescription = s.CassetteTypeDescription,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT
    (
    CassetteTypeCode,
    CassetteTypeDescription,
    CreatedBy,
    CreatedOn,
    UpdatedBy,
    UpdatedOn,
    IsActive
    )
    VALUES
    (
    s.CassetteTypeCode,
    s.CassetteTypeDescription,
    s.CreatedBy,
    s.CreatedOn,
    s.CreatedBy,
    s.CreatedOn,
    s.IsActive
    );


