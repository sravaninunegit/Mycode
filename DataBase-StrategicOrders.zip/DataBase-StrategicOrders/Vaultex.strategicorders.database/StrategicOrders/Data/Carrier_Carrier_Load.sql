﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Populate [Carrier].[Carrier] with business codes, copied from carrier domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
SET IDENTITY_INSERT [Carrier].[Carrier] ON;

WITH ExpectedRows
AS (SELECT PC.[CarrierID],
           PC.[CarrierCode],
           PC.[CarrierDescription],
           PC.[CreatedBy],
           PC.[CreatedOn],
           PC.[IsActive]
    FROM
    (
        VALUES
            (1, N'BRI', N'Brinks', N'CarrierLoadETL', GETDATE(), 1),
            (2, N'CAR', N'Cardtronics', N'CarrierLoadETL', GETDATE(), 1),
            (3, N'KIN', N'Kings', N'CarrierLoadETL', GETDATE(), 1),
            (4, N'PIV', N'Pivotal', N'CarrierLoadETL', GETDATE(), 1),
            (5, N'BDI', N'BDI', N'CarrierLoadETL', GETDATE(), 1),
            (6, N'BRS', N'Bristol', N'CarrierLoadETL', GETDATE(), 1),
            (7, N'JAD', N'Jade', N'CarrierLoadETL', GETDATE(), 1),
            (8, N'LOO', N'Loomis', N'CarrierLoadETL', GETDATE(), 1),
            (9, N'VAU', N'Vaultex', N'CarrierLoadETL', GETDATE(), 1),
            (10, N'NOT', N'Note Machine', N'CarrierLoadETL', GETDATE(), 1),
            (11, N'SEC', N'Security+', N'CarrierLoadETL', GETDATE(), 1),
            (12, N'G4S', N'G4S', N'CarrierLoadETL', GETDATE(), 1),
            (13, N'ISA', N'ISA', N'CarrierLoadETL', GETDATE(), 1),
            (14, N'CBT', N'CBT', N'CarrierLoadETL', GETDATE(), 1),
            (15, N'POS', N'Post Office', N'CarrierLoadETL', GETDATE(), 1)
    ) PC ([CarrierID], [CarrierCode], [CarrierDescription], [CreatedBy], [CreatedOn], [IsActive]) )
MERGE INTO [Carrier].[Carrier] AS t
USING ExpectedRows AS s
ON s.CarrierID = t.CarrierID
WHEN NOT MATCHED THEN
    INSERT
    (
        [CarrierID],
        [CarrierCode],
        [CarrierDescription],
        [CreatedBy],
        [CreatedOn],
        [IsActive]
    )
    VALUES
    (s.[CarrierID], s.[CarrierCode], s.[CarrierDescription], s.[CreatedBy], s.[CreatedOn], s.[IsActive])
WHEN MATCHED AND (
                     t.CarrierCode <> s.CarrierCode
                     OR t.CarrierDescription <> s.CarrierDescription
                     OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET t.CarrierCode = s.CarrierCode,
               t.CarrierDescription = s.CarrierDescription,
               t.UpdatedBy = s.CreatedBy,
               t.UpdatedOn = s.CreatedOn,
               t.IsActive = s.IsActive;
SET IDENTITY_INSERT [Carrier].[Carrier] OFF;
