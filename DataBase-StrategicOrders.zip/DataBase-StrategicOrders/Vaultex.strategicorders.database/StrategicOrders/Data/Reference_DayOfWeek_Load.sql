﻿IF NOT EXISTS (SELECT NULL FROM Reference.DayOfWeek WHERE DayOfWeekID = -1)
BEGIN
    SET IDENTITY_INSERT Reference.DayOfWeek ON;
    INSERT INTO Reference.DayOfWeek (  
        DayOfWeekID,
        DayOfWeekCode,              
        DayOfWeekDescription, 
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
        )
    VALUES (
        -1, 
        'UNK', 
        'Unknown', 
        'DB', 
        SYSDATETIME(), 
        'DB', 
        SYSDATETIME(),
        1
        )
    SET IDENTITY_INSERT Reference.DayOfWeek OFF;
END;

MERGE INTO Reference.DayOfWeek AS t
USING
(
SELECT
   s.DayOfWeekCode,
   s.DayOfWeekDescription,
   s.CreatedBy,
   s.CreatedOn,
   s.IsActive
FROM
(
VALUES
     ('ANY', 'Any day', 'DB', SYSDATETIME(), 1),
     ('MON', 'Monday', 'DB', SYSDATETIME(), 1),
     ('TUE', 'Tuesday', 'DB', SYSDATETIME(), 1),
     ('WED', 'Wednesday', 'DB', SYSDATETIME(), 1),
     ('THU', 'Thursday', 'DB', SYSDATETIME(), 1),
     ('FRI', 'Friday', 'DB', SYSDATETIME(), 1),
     ('SAT', 'Saturday', 'DB', SYSDATETIME(), 1),
     ('SUN', 'Sunday', 'DB', SYSDATETIME(), 1)
	
) s 
(DayOfWeekCode, DayOfWeekDescription, CreatedBy, CreatedOn, IsActive) ) AS s
ON t.DayOfWeekCode = s.DayOfWeekCode
WHEN MATCHED AND (t.DayOfWeekDescription <> s.DayOfWeekDescription
                 OR t.IsActive <> s.IsActive) THEN
    UPDATE SET
      t.DayOfWeekDescription = s.DayOfWeekDescription,
      t.UpdatedBy = s.CreatedBy,
      t.UpdatedOn = s.CreatedOn,
      t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
INSERT
    (  
    DayOfWeekCode,
    DayOfWeekDescription,
    CreatedBy,
    CreatedOn,
    UpdatedBy,
    UpdatedOn,
    IsActive
    )
VALUES
    (
     s.DayOfWeekCode,
     s.DayOfWeekDescription,
     s.CreatedBy,
     s.CreatedOn,
     s.CreatedBy,
     s.CreatedOn,
     s.IsActive
     );

