﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Populate [Reference].[QualityType] with business codes, copied from org. domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
SET IDENTITY_INSERT [Reference].[QualityType] ON;

WITH ExpectedRows
AS (SELECT PC.[QualityTypeID],
           PC.[QualityTypeCode],
           PC.[QualityTypeDescription],
           PC.[CreatedBy],
           PC.[CreatedOn],
           PC.[IsActive]
    FROM
    (
        VALUES
            (1, N'NOTE', N'NOTE', N'DB', GETDATE(), 1),
            (2, N'COIN', N'COIN', N'DB', GETDATE(), 1),
            (3, N'OTHER', N'OTHER', N'DB', GETDATE(), 1)
    ) PC ([QualityTypeID], [QualityTypeCode], [QualityTypeDescription], [CreatedBy], [CreatedOn], [IsActive]) )
MERGE INTO Reference.QualityType AS t
USING ExpectedRows AS s
ON s.QualityTypeID = t.QualityTypeID
WHEN NOT MATCHED THEN
    INSERT
    (
        [QualityTypeID],
        [QualityTypeCode],
        [QualityTypeDescription],
        [CreatedBy],
        [CreatedOn],
        [IsActive]
    )
    VALUES
    (s.[QualityTypeID], s.[QualityTypeCode], s.[QualityTypeDescription], s.[CreatedBy], s.[CreatedOn], s.[IsActive])
WHEN MATCHED AND (
                     t.QualityTypeCode <> s.QualityTypeCode
                     OR t.QualityTypeDescription <> s.QualityTypeDescription
                     OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET t.QualityTypeCode = s.QualityTypeCode,
               t.QualityTypeDescription = s.QualityTypeDescription,
               t.UpdatedBy = s.CreatedBy,
               t.UpdatedOn = s.CreatedOn,
               t.IsActive = s.IsActive;

SET IDENTITY_INSERT [Reference].[QualityType] OFF;
