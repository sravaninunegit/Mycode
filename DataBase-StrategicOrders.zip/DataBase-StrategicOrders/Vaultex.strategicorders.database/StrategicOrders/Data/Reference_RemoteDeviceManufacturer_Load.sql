﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Populate [Reference].[RemoteDeviceManufacturer] with business codes, copied from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
IF NOT EXISTS (SELECT NULL FROM Reference.RemoteDeviceManufacturer WHERE RemoteDeviceManufacturerID = -1)
BEGIN
    SET IDENTITY_INSERT Reference.RemoteDeviceManufacturer ON;
    INSERT INTO Reference.RemoteDeviceManufacturer
        (
        RemoteDeviceManufacturerID,
        RemoteDeviceManufacturerCode,
        RemoteDeviceManufacturerDescription,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
        )
    VALUES
        (
        -1,
        'UNK', 
        'Unknown', 
        SYSTEM_USER, 
        SYSDATETIME(), 
        SYSTEM_USER, 
        SYSDATETIME(), 
        1
        );
    SET IDENTITY_INSERT Reference.RemoteDeviceManufacturer OFF;
END;
MERGE INTO Reference.RemoteDeviceManufacturer AS t
USING
    (
    SELECT
        s.RemoteDeviceManufacturerCode,
        s.RemoteDeviceManufacturerDescription,
        s.CreatedBy,
        s.CreatedOn,
        s.IsActive
    FROM
    (
    VALUES

        ('DIE', 'Diebold', SYSTEM_USER, SYSDATETIME(), 1),
        ('HYO', 'Hyosung', SYSTEM_USER, SYSDATETIME(), 1),
        ('IBM', 'IBM', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', 'NCR', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', 'Siemens Nixdorf', SYSTEM_USER, SYSDATETIME(), 1),
        ('TRI', 'Triton ', SYSTEM_USER, SYSDATETIME(), 1)
    ) s (RemoteDeviceManufacturerCode, RemoteDeviceManufacturerDescription, CreatedBy, CreatedOn, IsActive)
    ) AS s
ON t.RemoteDeviceManufacturerCode = s.RemoteDeviceManufacturerCode
WHEN MATCHED AND (
                 t.RemoteDeviceManufacturerDescription <> s.RemoteDeviceManufacturerDescription
                 OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET
        t.RemoteDeviceManufacturerDescription = s.RemoteDeviceManufacturerDescription,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT
        (
        RemoteDeviceManufacturerCode,
        RemoteDeviceManufacturerDescription,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
        )
    VALUES
    (
      s.RemoteDeviceManufacturerCode,
      s.RemoteDeviceManufacturerDescription,
      s.CreatedBy,
      s.CreatedOn,
      s.CreatedBy,
      s.CreatedOn,
      s.IsActive
      );
