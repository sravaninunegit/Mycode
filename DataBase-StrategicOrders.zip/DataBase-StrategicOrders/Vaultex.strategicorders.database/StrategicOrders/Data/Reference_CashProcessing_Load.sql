﻿IF NOT EXISTS (SELECT NULL FROM Reference.CashProcessingRule WHERE CashProcessingRuleID = -1)
BEGIN
    SET IDENTITY_INSERT Reference.CashProcessingRule ON;
    INSERT INTO Reference.CashProcessingRule (
        CashProcessingRuleID,
        CashProcessingRuleCode,
        CashProcessingRuleDescription,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
    )
    VALUES (
        -1, 
        'UNK', 
        'Unknown', 
        SYSTEM_USER, 
        SYSDATETIME(), 
        SYSTEM_USER, 
        SYSDATETIME(),
        1
    )
    SET IDENTITY_INSERT Reference.CashProcessingRule OFF;
END
MERGE INTO Reference.CashProcessingRule AS t
USING
    (
    SELECT
        s.CashProcessingRuleCode,
        s.CashProcessingRuleDescription,
        s.CreatedBy,
        s.CreatedOn,
        s.IsActive
    FROM
    (
    VALUES
        ('CAP0001', 'Deferred Processing Allowed', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0002', 'DTP Only', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0003', 'Capture number of Wallets', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0004', 'Capture Till Number', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0005', 'Capture Section Number', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0006', 'Capture Serial Number', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0007', 'Capture Slip Date', SYSTEM_USER, SYSDATETIME(), 1),
		('CAP0008', 'Allow Part Bag', SYSTEM_USER, SYSDATETIME(), 1),
		('CAP0009', 'Allow Coin Order From Note Centre', SYSTEM_USER, SYSDATETIME(), 1),
		('CAP0010', 'Minimum Cassetting', SYSTEM_USER, SYSDATETIME(), 1),
		('CAP0011', 'Pack Type', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0012', 'Allow Mint Notes', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0013', 'Delivery Lead Time', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0014', 'Use Country Notes', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0015', 'Use Shot Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('CAP0016', 'Enable IVR Ordering', SYSTEM_USER, SYSDATETIME(), 1)
    ) s (CashProcessingRuleCode, CashProcessingRuleDescription, CreatedBy, CreatedOn, IsActive)
    ) AS s
ON t.CashProcessingRuleCode = s.CashProcessingRuleCode
WHEN MATCHED AND (
                 t.CashProcessingRuleDescription <> s.CashProcessingRuleDescription
                 OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET
        t.CashProcessingRuleDescription = s.CashProcessingRuleDescription,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT (
        CashProcessingRuleCode,
        CashProcessingRuleDescription,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
        )
    VALUES (
        s.CashProcessingRuleCode,
        s.CashProcessingRuleDescription,
        s.CreatedBy,
        s.CreatedOn,
        s.CreatedBy,
        s.CreatedOn,
        s.IsActive
    );


