﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 31/10/2024
-- Description: Populate CCSIVRMediaMap with code mappings.
-- History: 31/10/2024 : Resource 503436 : SOTPT-848
-- ==================================================================
MERGE INTO [Reference].[CCSIVRMediaMap] AS t
USING
    (
    SELECT [ProductCode], [CCIVRCode], [CCSITIDCode], t.[IsActive] FROM (
    VALUES
        ('GBPN05000103', 'A50.00', 'NA3P', 1),
        ('GBPN02000103', 'A20.00', 'NA4P', 1),
        ('GBPN01000103', 'A10.00', 'NA5P', 1),
        ('GBPN00500103', 'A5.00', 'NA6P', 1),
        ('GBPC00200009', 'C2.00', 'C2', 1),
        ('GBPC00100009', 'C1.00', 'C3', 1),
        ('GBPC00050009', 'C0.50', 'C4', 1),
        ('GBPC00020009', 'C0.20', 'C5', 1),
        ('GBPC00010009', 'C0.10', 'C6', 1),
        ('GBPC00005009', 'C0.05', 'C7', 1),
        ('GBPC00002009', 'C0.02', 'C8', 1),
        ('GBPC00001009', 'C0.01', 'C9', 1)) t ([ProductCode], [CCIVRCode], [CCSITIDCode], [IsActive])
    ) AS o
ON t.[ProductCode] = o.[ProductCode]
WHEN MATCHED AND (t.[CCIVRCode] != o.[CCIVRCode] OR t.[CCSITIDCode] != o.[CCSITIDCode] OR t.[IsActive] != o.[IsActive]) THEN
    UPDATE SET
        t.[CCIVRCode] = o.[CCIVRCode],
        t.[CCSITIDCode] = o.[CCSITIDCode],
        t.[UpdatedBy] = SYSTEM_USER,
        t.[UpdatedOn] = SYSDATETIME(),
        t.[ISActive] = o.[IsActive]
WHEN NOT MATCHED THEN
    INSERT (
        [ProductCode],
        [CCIVRCode],
        [CCSITIDCode],
        [CreatedBy],
        [CreatedOn],
		[IsActive]
       )
    VALUES (
        o.[ProductCode],
        o.[CCIVRCode],
        o.[CCSITIDCode],
        SYSTEM_USER,
        SYSDATETIME(),
		o.[IsActive]
    );
