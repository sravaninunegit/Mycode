﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Populate [Reference].[RemoteDeviceModel] with business codes, copied from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
IF NOT EXISTS (SELECT NULL FROM Reference.RemoteDeviceModel WHERE RemoteDeviceModelID = -1)
BEGIN
    SET IDENTITY_INSERT Reference.RemoteDeviceModel ON;
    INSERT INTO Reference.RemoteDeviceModel
        (
        RemoteDeviceModelID,
        RemoteDeviceManufacturerID,
        RemoteDeviceModelCode,
        RemoteDeviceModelDescription,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
        )
    VALUES
        (
        -1,
        -1,
        'UNK', 
        'Unknown', 
        SYSTEM_USER, 
        SYSDATETIME(), 
        SYSTEM_USER, 
        SYSDATETIME(), 
        1
        );
    SET IDENTITY_INSERT Reference.RemoteDeviceModel OFF;
END;
MERGE INTO Reference.RemoteDeviceModel AS t
USING
    (
    SELECT
        m.RemoteDeviceManufacturerID,
        s.RemoteDeviceModelCode,
        s.RemoteDeviceModelDescription,
        s.CreatedBy,
        s.CreatedOn,
        s.IsActive
    FROM
    (
    VALUES
        ('DIE', '0400', '0400', SYSTEM_USER, SYSDATETIME(), 1),
        ('DIE', '0450', '0450', SYSTEM_USER, SYSDATETIME(), 1),
        ('DIE', '5620', '5620', SYSTEM_USER, SYSDATETIME(), 1),
        ('DIE', 'UNK', 'Unknown', SYSTEM_USER, SYSDATETIME(), 1),
        ('HYO', '1500', '1500', SYSTEM_USER, SYSDATETIME(), 1),
        ('HYO', '1800', '1800', SYSTEM_USER, SYSDATETIME(), 1),
        ('HYO', 'UNK', 'Unknown', SYSTEM_USER, SYSDATETIME(), 1),
        ('IBM', 'UNK', 'Unknown', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '1500', '1500', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '0002', '0002', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '2000', '2000', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5003', '5003', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5070', '5070', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5084', '5084', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5305', '5305', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '0055', '0055', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5674', '5674', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5675', '5675', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5684', '5684', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5685', '5685', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5688', '5688', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5695', '5695', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5870', '5870', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5874', '5874', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5875', '5875', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5877', '5877', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5884', '5884', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5885', '5885', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5886', '5886', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '5887', '5887', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '6223', '6223', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '6614', '6614', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '6622', '6622', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '6623', '6623', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '6624', '6624', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '6625', '6625', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '6626', '6626', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '6628', '6628', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '6634', '6634', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '6684', '6684', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '0070', '0070', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '0077', '0077', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', '0087', '0087', SYSTEM_USER, SYSDATETIME(), 1),
        ('NCR', 'UNK', 'Unknown', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '1500', '1500', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '2040', '2040', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '2050', '2050', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '2100', '2100', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '2150', '2150', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '2550', '2550', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '2560', '2560', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '0280', '0280', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '0285', '0285', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '4090', '4090', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', '8050', '8050', SYSTEM_USER, SYSDATETIME(), 1),
        ('SIE', 'UNK', 'Unknown', SYSTEM_USER, SYSDATETIME(), 1),
        ('TRI', '2315', '2315', SYSTEM_USER, SYSDATETIME(), 1),
        ('TRI', '2325', '2325', SYSTEM_USER, SYSDATETIME(), 1),
        ('TRI', '3404', '3404', SYSTEM_USER, SYSDATETIME(), 1),
        ('TRI', '5115', '5115', SYSTEM_USER, SYSDATETIME(), 1),
        ('TRI', '5125', '5125', SYSTEM_USER, SYSDATETIME(), 1),
        ('TRI', '5325', '5325', SYSTEM_USER, SYSDATETIME(), 1),
        ('TRI', 'UNK', 'Unknown', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '1500', '1500', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '2000', '2000', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '2050', '2050', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '2054', '2054', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '2150', '2150', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '5667', '5667', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '5670', '5670', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '5674', '5674', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '5684', '5684', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '5685', '5685', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '5874', '5874', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '5877', '5877', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '5884', '5884', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '5885', '5885', SYSTEM_USER, SYSDATETIME(), 1),
        ('UNK', '5887', '5887', SYSTEM_USER, SYSDATETIME(), 1)
    ) s (RemoteDeviceManufacturerCode, RemoteDeviceModelCode, RemoteDeviceModelDescription, CreatedBy, CreatedOn, IsActive)
    INNER JOIN Reference.RemoteDeviceManufacturer m ON s.RemoteDeviceManufacturerCode = m.RemoteDeviceManufacturerCode 
    ) AS s
ON t.RemoteDeviceManufacturerId = s.RemoteDeviceManufacturerId AND t.RemoteDeviceModelCode = s.RemoteDeviceModelCode
WHEN MATCHED AND (
                 t.RemoteDeviceModelDescription <> s.RemoteDeviceModelDescription
                 OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET
        t.RemoteDeviceModelDescription = s.RemoteDeviceModelDescription,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT
        (
        RemoteDeviceManufacturerId,
        RemoteDeviceModelCode,
        RemoteDeviceModelDescription,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
        )
    VALUES
    (
      s.RemoteDeviceManufacturerId,
      s.RemoteDeviceModelCode,
      s.RemoteDeviceModelDescription,
      s.CreatedBy,
      s.CreatedOn,
      s.CreatedBy,
      s.CreatedOn,
      s.IsActive
      );
