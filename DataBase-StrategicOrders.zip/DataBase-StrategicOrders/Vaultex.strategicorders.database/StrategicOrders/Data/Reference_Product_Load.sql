﻿IF NOT EXISTS (SELECT NULL FROM Reference.Product WHERE ProductID = -1)
BEGIN
    SET IDENTITY_INSERT Reference.Product ON;
    INSERT INTO Reference.Product (
        ProductID, 
        ProductCode, 
        ProductDescription, 
        CreatedBy, 
        CreatedOn,
        UpdatedBy, 
        UpdatedOn,
        IsActive
    )
    VALUES (
        -1, 
        'UNK', 
        'Unknown', 
        SYSTEM_USER, 
        SYSDATETIME(),
        SYSTEM_USER, 
        SYSDATETIME(),
        1
    )
    SET IDENTITY_INSERT Reference.Product OFF;
END
MERGE INTO Reference.Product AS t
USING
    (
    SELECT
        s.ProductCode, 
        s.ProductDescription, 
        s.CreatedBy, 
        s.CreatedOn, 
        s.IsActive
    FROM
    (
    VALUES
        ('BCS', 'Barclays Collect (BCS)', SYSTEM_USER, SYSDATETIME(), 1),
        ('BPI', 'Business Pay In (BPI)', SYSTEM_USER, SYSDATETIME(), 1),
        ('CBT', 'Carrier Bulk Till (CBT)', SYSTEM_USER, SYSDATETIME(), 1),
        ('CRC', 'Credit Checking', SYSTEM_USER, SYSDATETIME(), 1),
        ('DFC', 'Deferred Checking', SYSTEM_USER, SYSDATETIME(), 1),
        ('PRC', 'Prime Count', SYSTEM_USER, SYSDATETIME(), 1),
        ('OUT', 'Cash Out', SYSTEM_USER, SYSDATETIME(), 1)
    ) s (ProductCode, ProductDescription, CreatedBy, CreatedOn, IsActive)
    ) AS s
ON t.ProductCode = s.ProductCode
WHEN MATCHED AND (
                 t.ProductDescription <> s.ProductDescription
                 OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET
        t.ProductDescription = s.ProductDescription,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT (
        ProductCode, 
        ProductDescription, 
        CreatedBy, 
        CreatedOn,
        UpdatedBy, 
        UpdatedOn,
        IsActive
        )
    VALUES (
        s.ProductCode, 
        s.ProductDescription, 
        s.CreatedBy, 
        s.CreatedOn,
        s.CreatedBy, 
        s.CreatedOn, 
        s.IsActive
    );


