﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Populate [Reference].[Issuer] with business codes, copied from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
IF NOT EXISTS (SELECT NULL FROM Reference.Issuer WHERE IssuerId = -1)
BEGIN
    SET IDENTITY_INSERT Reference.Issuer ON;
    INSERT INTO Reference.Issuer (
        IssuerID, 
        IssuerCode, 
        IssuerDescription, 
        CreatedBy, 
        CreatedOn, 
        UpdatedBy,
        UpdatedOn,
        IsActive
    )
    VALUES 
        (-1, 'UNK', 'Unknown', SYSTEM_USER, SYSDATETIME(), SYSTEM_USER, SYSDATETIME(), 1)
    SET IDENTITY_INSERT Reference.Issuer OFF;
END
MERGE INTO Reference.Issuer AS t
USING
    (
    SELECT
        s.IssuerCode, s.IssuerDescription, s.CreatedBy, s.CreatedOn, s.IsActive
    FROM
    (
    VALUES
        ('BOE', 'Bank Of England', SYSTEM_USER, SYSDATETIME(), 1),
        ('BOI', 'Bank Of Ireland', SYSTEM_USER, SYSDATETIME(), 1),
        ('BOS', 'Bank Of Scotland', SYSTEM_USER, SYSDATETIME(), 1),
        ('CLY', 'Clydesdale Bank', SYSTEM_USER, SYSDATETIME(), 1),
        ('DAN', 'Danske Bank', SYSTEM_USER, SYSDATETIME(), 1),
        ('FTB', 'First Trust Bank', SYSTEM_USER, SYSDATETIME(), 1),
        ('RBS', 'Royal Bank Of Scotland', SYSTEM_USER, SYSDATETIME(), 1),
        ('ULS', 'Ulster Bank', SYSTEM_USER, SYSDATETIME(), 1),
        ('SCO', 'Mixed Scottish', SYSTEM_USER, SYSDATETIME(), 1),
        ('IRI', 'Mixed Irish', SYSTEM_USER, SYSDATETIME(), 1)
    ) s (IssuerCode, IssuerDescription, CreatedBy, CreatedOn, IsActive)
    ) AS s
ON t.IssuerCode = s.IssuerCode
WHEN MATCHED AND (
                 t.IssuerDescription <> s.IssuerDescription
                 OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET
        t.IssuerDescription = s.IssuerDescription,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT
        (
        IssuerCode, 
        IssuerDescription, 
        CreatedBy, 
        CreatedOn, 
        UpdatedBy, 
        UpdatedOn,
        IsActive
        )
    VALUES
    (s.IssuerCode, s.IssuerDescription, s.CreatedBy, s.CreatedOn, s.CreatedBy, s.CreatedOn, s.IsActive);


