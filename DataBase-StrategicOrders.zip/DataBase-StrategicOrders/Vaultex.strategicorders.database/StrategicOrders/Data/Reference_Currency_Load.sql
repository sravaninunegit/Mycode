﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Populate [Reference].[Currency] with business codes, copied from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
IF NOT EXISTS (SELECT NULL FROM Reference.Currency WHERE CurrencyId = -1)
BEGIN
    SET IDENTITY_INSERT Reference.Currency ON;
    INSERT INTO Reference.Currency (
        CurrencyId,
        CurrencyCode,
        CurrencyDescription,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
    )
    VALUES
     (-1, 'UNK', 'Unknown', SYSTEM_USER, SYSDATETIME(), SYSTEM_USER, SYSDATETIME(), 1)
    SET IDENTITY_INSERT Reference.Currency OFF;
END
MERGE INTO Reference.Currency AS t
USING
(SELECT
    s.CurrencyCode,
    s.CurrencyDescription,
    s.CreatedBy,
    s.CreatedOn,
    s.IsActive
 FROM
(VALUES
     ('GBP', 'Pound Sterling', SYSTEM_USER, SYSDATETIME(), 1)
   ) s (CurrencyCode, CurrencyDescription, CreatedBy, CreatedOn, IsActive) ) AS s
ON t.CurrencyCode = s.CurrencyCode
WHEN MATCHED AND (t.CurrencyDescription <> s.CurrencyDescription
                 OR t.IsActive <> s.IsActive) THEN
    UPDATE SET
        t.CurrencyCode = s.CurrencyCode,
        t.CurrencyDescription = s.CurrencyDescription,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT (
        CurrencyCode,
        CurrencyDescription,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
    )
    VALUES (
        s.CurrencyCode,
        s.CurrencyDescription,
        s.CreatedBy,
        s.CreatedOn,
        s.CreatedBy,
        s.CreatedOn,
        s.IsActive
   );


