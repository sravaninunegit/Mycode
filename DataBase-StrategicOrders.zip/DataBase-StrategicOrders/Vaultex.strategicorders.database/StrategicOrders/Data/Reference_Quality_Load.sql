﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Populate [Reference].[Quality] with business codes, copied from org. domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
SET IDENTITY_INSERT [Reference].[Quality] ON;

WITH ExpectedRows
AS (SELECT PC.[QualityID],
           PC.[QualityTypeID],
           PC.[QualityCode],
           PC.[QualityDescription],
           PC.[CreatedBy],
           PC.[CreatedOn],
           PC.[IsActive]
    FROM
    (
        VALUES
            (1, 2, N'015', N'Shot coin', N'DB', GETDATE(), 1),
            (2, 2, N'018', N'New coin', N'DB', GETDATE(), 1),
            (3, 2, N'019', N'Old series coin loose', N'DB', GETDATE(), 1),
            (4, 2, N'020', N'Old series forgery', N'DB', GETDATE(), 1),
            (5, 2, N'021', N'Old series scrap', N'DB', GETDATE(), 1),
            (6, 2, N'011', N'Sundry coin', N'DB', GETDATE(), 1),
            (7, 2, N'010', N'Loose coin', N'DB', GETDATE(), 1),
            (8, 2, N'016', N'Machine verified coin', N'DB', GETDATE(), 1),
            (9, 2, N'009', N'Sachet coin', N'DB', GETDATE(), 1),
            (10, 2, N'022', N'Scrap coin', N'DB', GETDATE(), 1),
            (11, 2, N'023', N'Country coin', N'DB', GETDATE(), 1),
            (12, 2, N'024', N'Old series coin liner', N'DB', GETDATE(), 1),
            (13, 2, N'025', N'Old series coin garbled', N'DB', GETDATE(), 1),
            (14, 2, N'026', N'Mixed coin', N'DB', GETDATE(), 1),
            (15, 2, N'027', N'Forgeries coin', N'DB', GETDATE(), 1),
            (16, 2, N'008', N'Rolled coin', N'DB', GETDATE(), 1),
            (17, 2, N'017', N'Liner coin', N'DB', GETDATE(), 1),
            (18, 1, N'001', N'Mixed note', N'DB', GETDATE(), 1),
            (19, 1, N'013', N'Forgeries note', N'DB', GETDATE(), 1),
            (20, 1, N'012', N'Old note', N'DB', GETDATE(), 1),
            (21, 1, N'007', N'Country note', N'DB', GETDATE(), 1),
            (22, 1, N'006', N'Soiled note (Paper)', N'DB', GETDATE(), 1),
            (23, 1, N'005', N'MOS', N'DB', GETDATE(), 1),
            (24, 1, N'004', N'Re-issue note', N'DB', GETDATE(), 1),
            (25, 1, N'003', N'ATM fit note (Paper)', N'DB', GETDATE(), 1),
            (26, 1, N'002', N'New note', N'DB', GETDATE(), 1),
            (27, 1, N'103', N'A-FIT (Polymer)', N'DB', GETDATE(), 1),
            (28, 1, N'106', N'Soiled A-FIT (Polymer)', N'DB', GETDATE(), 1),
            (29, 3, N'014', N'Non-Cash', N'DB', GETDATE(), 1)
    ) PC ([QualityID], [QualityTypeID], [QualityCode], [QualityDescription], [CreatedBy], [CreatedOn], [IsActive]) )
MERGE INTO Reference.Quality AS t
USING ExpectedRows AS s
ON s.QualityID = t.QualityID
WHEN NOT MATCHED THEN
    INSERT
    (
        [QualityID],
        [QualityTypeID],
        [QualityCode],
        [QualityDescription],
        [CreatedBy],
        [CreatedOn],
        [IsActive]
    )
    VALUES
    (s.[QualityID], s.[QualityTypeID], s.[QualityCode], s.[QualityDescription], s.[CreatedBy], s.[CreatedOn], s.[IsActive])
WHEN MATCHED AND (
                     t.QualityTypeID <> s.QualityTypeID
                     OR t.QualityCode <> s.QualityCode
                     OR t.QualityDescription <> s.QualityDescription
                     OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET t.QualityTypeID = s.QualityTypeID,
               t.QualityCode = s.QualityCode,
               t.QualityDescription = s.QualityDescription,
               t.UpdatedBy = s.CreatedBy,
               t.UpdatedOn = s.CreatedOn,
               t.IsActive = s.IsActive;

SET IDENTITY_INSERT [Reference].[Quality] OFF;
