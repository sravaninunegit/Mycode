﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 18/10/2024
-- Description: Upset cash centre codes.
-- History: 18/10/2024 : Resource 503436 : SOTPT-726
-- ==================================================================
BEGIN
MERGE INTO [Reference].[CashCentre] AS t
USING
    (
	    SELECT
        o.[CashCentreCode],
        o.[CashCentreDescription],       
        o.[CashCentreTypeCode],
        o.[CreatedBy]
    FROM
    (
    VALUES
		('5102', 'Birmingham', 'NOTE', 'DB'),
		('5105', 'Bristol', 'NOTE', 'DB'),
		('5107', 'Bristol', 'COIN', 'DB'),
		('5109', 'Kilmarnock', 'NOTE', 'DB'),
		('5110', 'Washington', 'NOTE', 'DB'),
		('5111', 'Leeds', 'NOTE', 'DB'),
		('5112', 'Leeds', 'COIN', 'DB'),
		('5114', 'Tonbridge', 'NOTE', 'DB'),
		('5115', 'Kings Cross', 'NOTE', 'DB'),
		('5117', 'Dagenham', 'COIN', 'DB'),
		('5118', 'Manchester', 'COIN', 'DB'),
		('5124', 'Woolston', 'NOTE', 'DB'),
		('5142', 'Call Centre', 'NOTE', 'DB'),
		('5152', 'Birmingham', 'COIN', 'DB'),
		('5154', 'Glasgow', 'COIN', 'DB'),
		('5155', 'Bridgewater Place', 'SUPPORT', 'DB'),
		('5166', 'Garlic Hill', 'SUPPORT', 'DB'), -- VX's most delicious location 🧄
		('5199', 'Central', 'COIN', 'DB'),
		('5360', 'Northern Ireland', 'NOTE', 'DB'),
		('5361', 'Northern Ireland', 'COIN', 'DB')
    ) o ([CashCentreCode],[CashCentreDescription],[CashCentreTypeCode],[CreatedBy])
    ) AS o
ON t.[CashCentreCode] = o.[CashCentreCode]
WHEN MATCHED AND (t.[CashCentreDescription] != o.[CashCentreDescription] OR t.[CashCentreTypeCode] != o.[CashCentreTypeCode]) THEN
    UPDATE SET
        t.[CashCentreCode] = o.[CashCentreCode],
        t.[CashCentreDescription] = o.[CashCentreDescription],
        t.[CashCentreTypeCode] = o.[CashCentreTypeCode],
		t.[UpdatedOn] = GETDATE()
WHEN NOT MATCHED THEN
    INSERT (
        [CashCentreCode],
        [CashCentreDescription],
		[CashCentreTypeCode],
        [CreatedBy],
		[CreatedOn],
		[IsActive]
       )
    VALUES (
        o.[CashCentreCode],
        o.[CashCentreDescription],        
        o.[CashCentreTypeCode],
        o.[CreatedBy],
		GETDATE(),
		1
    );
END

