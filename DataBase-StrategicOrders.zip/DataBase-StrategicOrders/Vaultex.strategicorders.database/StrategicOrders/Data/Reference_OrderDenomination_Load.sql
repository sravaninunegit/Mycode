﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
BEGIN
MERGE INTO [Reference].[OrderingDenominations] AS t
USING
    (
    SELECT
        s.Code,        
        s.Description,		
        s.CreatedBy
    FROM
    (
    VALUES
       ('GBPN10000','£100 note','DB'),
       ('GBPN05000','£50 note','DB'),
	   ('GBPN02000','£20 note','DB'),
	   ('GBPN01000','£10 note','DB'),
	   ('GBPN00500','£5 note','DB'),
	   ('GBPN00100','£1 note','DB'),
	   ('GBPC00200','£2 coin','DB'),
	   ('GBPC00100','£1 coin','DB'),
	   ('GBPC00050','50p coin','DB'),
	   ('GBPC00020','20p coin','DB'),
	   ('GBPC00010','10p coin','DB'),
	   ('GBPC00005','5p coin','DB'),
	   ('GBPC00002','2p coin','DB'),
	   ('GBPC00001','1p coin','DB')
    ) s (Code,Description,CreatedBy)
    ) AS s
ON t.Code = s.Code
WHEN MATCHED AND (
                 t.Description <> s.Description                 
                 ) THEN
    UPDATE SET
        t.Code = s.Code,
        t.Description = s.Description,       
        t.CreatedBy = s.CreatedBy
WHEN NOT MATCHED THEN
    INSERT (
        Code,
        Description,       
        CreatedBy
       )
    VALUES (
        s.Code,
        s.Description,       
        s.CreatedBy
    );
END