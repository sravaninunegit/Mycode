﻿-- Create a temporary table to store the combinations
CREATE TABLE #TempService (
    ServiceTypeID INT,
    ServiceCode NVARCHAR(50),
    ServiceDescription NVARCHAR(255),
    CreatedBy NVARCHAR(100),
    CreatedOn DATETIME,
    IsActive BIT
);

-- Insert the combinations into the temporary table
INSERT INTO #TempService (ServiceTypeID, ServiceCode, ServiceDescription, CreatedBy, CreatedOn, IsActive)
SELECT
    st.ServiceTypeID,
    s.ServiceCode, 
    s.ServiceDescription,
    s.CreatedBy,
    s.CreatedOn,
    s.IsActive
FROM
(
    VALUES 
        ('CI', 'Cash In', SYSTEM_USER, SYSDATETIME(), 1),
        ('CO', 'Cash Out', SYSTEM_USER, SYSDATETIME(), 1)
) s (ServiceCode, ServiceDescription, CreatedBy, CreatedOn, IsActive)
CROSS JOIN Reference.ServiceType st;

-- Insert the unknown service if it doesn't exist
IF NOT EXISTS (SELECT NULL FROM Reference.Service WHERE ServiceID = -1)
BEGIN
    SET IDENTITY_INSERT Reference.Service ON;
    INSERT INTO Reference.Service (
        ServiceID, 
        ServiceTypeId, 
        ServiceCode, 
        ServiceDescription, 
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
    )
    VALUES (
        -1, 
        -1, 
        'UNK', 
        'Unknown', 
        SYSTEM_USER, 
        SYSDATETIME(), 
        SYSTEM_USER, 
        SYSDATETIME(),
        1
    )
    SET IDENTITY_INSERT Reference.Service OFF;
END

-- Merge the data from the temporary table into the target table
MERGE INTO Reference.Service AS t
USING #TempService AS s
ON t.ServiceTypeId = s.ServiceTypeID AND t.ServiceCode = s.ServiceCode
WHEN MATCHED AND (
                 t.ServiceDescription <> s.ServiceDescription
                 OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET
        t.ServiceDescription = s.ServiceDescription,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT (
        ServiceTypeID, 
        ServiceCode, 
        ServiceDescription, 
        CreatedBy, 
        CreatedOn,
        UpdatedBy, 
        UpdatedOn,
        IsActive
    )
    VALUES (
        s.ServiceTypeID, 
        s.ServiceCode, 
        s.ServiceDescription, 
        s.CreatedBy, 
        s.CreatedOn,
        s.CreatedBy, 
        s.CreatedOn,
        s.IsActive
    );

-- Drop the temporary table
DROP TABLE #TempService;
