﻿-- ==================================================================
-- Author:      Resource 503436
-- Create Date: 29/10/2024
-- Description: Populate [Reference].[Denomination] with business codes, copied from customer domain.
-- History: 29/10/2024 : Resource 503436 : SOTPT-832
-- ==================================================================
IF NOT EXISTS (SELECT NULL FROM Reference.Denomination WHERE DenominationId = -1)
BEGIN
    SET IDENTITY_INSERT Reference.Denomination ON;
    INSERT INTO Reference.Denomination (
        DenominationID,
        DenominationCode,
        DenominationDescription,
        DenominationValue,
        DenominationType,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
    )
    VALUES
        (-1, 'UNK', 'Unknown', 0, 'UNK ', SYSTEM_USER, SYSDATETIME(), SYSTEM_USER, SYSDATETIME(), 1)
    SET IDENTITY_INSERT Reference.Denomination OFF;
END
MERGE INTO Reference.Denomination AS t
USING
    (
    SELECT
        s.DenominationCode,
        s.DenominationDescription,
        s.DenominationValue,
        s.DenominationType,
        s.CreatedBy,
        s.CreatedOn,
        s.IsActive
    FROM
    (
    VALUES
        ('GBPCMIXED', 'Mixed coin xxp', 1, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPC00001', '1p', 1, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPC00002', '2p', 2, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPC00005', '5p', 5, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPC00010', '10p', 10, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPC00020', '20p', 20, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPC00050', '50p', 50, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPC00100', '£1', 100, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPC00200', '£2', 200, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPC00500', '£5', 500, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPC90000', 'Commemorative coin', 1, 'Coin', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPN00100', '£1', 100, 'Note', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPN00500', '£5', 500, 'Note', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPN01000', '£10', 1000, 'Note', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPN02000', '£20', 2000, 'Note', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPN05000', '£50', 5000, 'Note', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPN10000', '£100', 10000, 'Note', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPN90001', 'Old series Notes/ Non Standard', 100, 'Note', SYSTEM_USER, SYSDATETIME(), 1),
        ('GBPNMIXED', 'Mixed notes £xxx', 100, 'Note', SYSTEM_USER, SYSDATETIME(), 1),
        ('IRINMIXED', 'Mixed Irish notes', 0, 'Note', SYSTEM_USER, SYSDATETIME(), 1),
        ('SCONMIXED', 'Mixed Scottish notes', 0, 'Note', SYSTEM_USER, SYSDATETIME(), 1)
    ) s (DenominationCode, DenominationDescription, DenominationValue, DenominationType, CreatedBy, CreatedOn, IsActive)
    ) AS s
ON t.DenominationCode = s.DenominationCode
WHEN MATCHED AND (
                 t.DenominationDescription <> s.DenominationDescription
                 OR t.DenominationValue <> s.DenominationValue
                 OR t.DenominationType <> s.DenominationType
                 OR t.IsActive <> s.IsActive
                 ) THEN
    UPDATE SET
        t.DenominationDescription = s.DenominationDescription,
        t.DenominationValue = s.DenominationValue,
        t.DenominationType = s.DenominationType,
        t.UpdatedBy = s.CreatedBy,
        t.UpdatedOn = s.CreatedOn,
        t.IsActive = s.IsActive
WHEN NOT MATCHED THEN
    INSERT
        (
        DenominationCode,
        DenominationDescription,
        DenominationValue,
        DenominationType,
        CreatedBy,
        CreatedOn,
        UpdatedBy,
        UpdatedOn,
        IsActive
        )
    VALUES
    (
        s.DenominationCode,
        s.DenominationDescription,
        s.DenominationValue,
        s.DenominationType,
        s.CreatedBy,
        s.CreatedOn,
        s.CreatedBy,
        s.CreatedOn,
        s.IsActive);


