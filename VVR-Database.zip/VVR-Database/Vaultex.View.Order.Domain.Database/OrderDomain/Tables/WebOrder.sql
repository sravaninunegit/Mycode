CREATE TABLE [dbo].[WebOrder]
(
    [WebOrderId] BIGINT IDENTITY(1,1) NOT NULL, 
    [OrderType] VARCHAR(1) NOT NULL, 
    [CustomerNumber] VARCHAR(17) NOT NULL, 
    [DeliveryDate] VARCHAR(8) NOT NULL, 
    [OrderValue] DECIMAL(16, 2) NOT NULL, 
    [CashCentreCode] VARCHAR(4) NOT NULL, 
    [BankSortCode] VARCHAR(6) NOT NULL, 
    [AccountNumber] VARCHAR(8) NOT NULL, 
    [OrderDateTime] VARCHAR(16) NOT NULL,
    [CreatedBy] VARCHAR(100) NOT NULL,
    [CreatedOn] DATETIME2(7) NOT NULL,
    [UpdatedBy] VARCHAR(100) NULL,
    [UpdatedOn] DATETIME2(7) NULL,
    [DeletedBy] VARCHAR(100) NULL,
    [DeletedOn] DATETIME2(7) NULL,
    [RowLockVersion] ROWVERSION NOT NULL,
    [IsActive] BIT NOT NULL,
    [SourceType] [int] NOT NULL
    CONSTRAINT [PK_WebOrder] PRIMARY KEY CLUSTERED ([WebOrderId] ASC)
    -- "Basically, you set PAD_INDEX = ON if you expect a lot of random changes to the index regularly."
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[WebOrder]
ADD CONSTRAINT [DF_OrderDomain_WebOrder_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[WebOrder]
ADD CONSTRAINT [DF_OrderDomain_WebOrder_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[WebOrder]
ADD CONSTRAINT [DF_OrderDomain_WebOrder_IsActive]
    DEFAULT (1) FOR [IsActive]
Go
    ALTER TABLE [dbo].[WebOrder]
ADD CONSTRAINT [DF_OrderDomain_WebOrder_SourceType]
    DEFAULT (0) FOR [SourceType]
GO
