CREATE TABLE [dbo].[MediaTypeMap]
(
    [MediaTypeMapId] BIGINT IDENTITY(1,1) NOT NULL,
    [MediaType] VARCHAR(13) NOT NULL,
    [CCSItId] VARCHAR(5) NOT NULL,
    [Denomination] DECIMAL(16, 2) NOT NULL,
    [UnitsPerPack] INT NOT NULL,
    [CreatedBy] VARCHAR(100) NOT NULL,
    [CreatedOn] DATETIME2(7) NOT NULL,
    [UpdatedBy] VARCHAR(100) NULL,
    [UpdatedOn] DATETIME2(7) NULL,
    [DeletedBy] VARCHAR(100) NULL,
    [DeletedOn] DATETIME2(7) NULL,
    [RowLockVersion] ROWVERSION NOT NULL,
    [IsActive] BIT NOT NULL,
    CONSTRAINT [PK_MediaTypeMap] PRIMARY KEY CLUSTERED ([MediaTypeMapId] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY], 
    CONSTRAINT [UQ_MediaType] UNIQUE ([MediaType])
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[MediaTypeMap] 
ADD CONSTRAINT [DF_OrderDomain_MediaTypeMap_CreatedOn] 
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[MediaTypeMap]
ADD CONSTRAINT [DF_OrderDomain_MediaTypeMap_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[MediaTypeMap]
ADD CONSTRAINT [DF_OrderDomain_MediaTypeMap_IsActive]
    DEFAULT (1) FOR [IsActive]
GO

ALTER TABLE [dbo].[MediaTypeMap]
ADD CONSTRAINT [DF_OrderDomain_MediaTypeMap_Denomination]
    DEFAULT (0.00) FOR [Denomination]    
GO

ALTER TABLE [dbo].[MediaTypeMap]
ADD CONSTRAINT [DF_OrderDomain_MediaTypeMap_UnitsPerPack]
    DEFAULT (0) FOR [UnitsPerPack]    
GO
