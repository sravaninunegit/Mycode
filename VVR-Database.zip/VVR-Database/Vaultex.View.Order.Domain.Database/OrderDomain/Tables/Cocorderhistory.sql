CREATE TABLE [dbo].[Cocorderhistory](
	[CocorderhistoryId] [bigint] IDENTITY(1,1) NOT NULL,
	[primkey] [varchar](28) NOT NULL,
	[ordtype] [varchar](1) NOT NULL,
	[lcuno] [varchar](17) NOT NULL,
	[ddate] [varchar](8) NOT NULL,
	[uniqueid] [varchar](2) NOT NULL,
	[totval] [decimal](16, 2) NOT NULL,
	[centre] [varchar](4) NOT NULL,
	[account] [varchar](16) NOT NULL,
	[cashSpec] [text] NULL,
	[regStamp] [varchar](12) NOT NULL,
	[carriertimes] [varchar](14) NOT NULL,
	[state] [varchar](1) NOT NULL,
	[CreatedBy] [varchar](100) NOT NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[UpdatedBy] [varchar](100) NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[DeletedBy] [varchar](100) NULL,
	[DeletedOn] [datetime2](7) NULL,
	[RowLockVersion] [timestamp] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[IsWrittentoCoc] [bit] NOT NULL,
    [SourceType] [int] NOT NULL
 CONSTRAINT [PK_Cocorderhistory] PRIMARY KEY CLUSTERED 
(
	[CocorderhistoryId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Cocorderhistory] ADD  CONSTRAINT [DF_OrderDomain_Cocorderhistory_CreatedBy]  DEFAULT (suser_sname()) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[Cocorderhistory] ADD  CONSTRAINT [DF_OrderDomain_Cocorderhistory_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[Cocorderhistory] ADD  CONSTRAINT [DF_OrderDomain_Cocorderhistory_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
 ALTER TABLE [dbo].[Cocorderhistory]
ADD CONSTRAINT [DF_OrderDomain_Cocorderhistory_SourceType]
    DEFAULT (0) FOR [SourceType]
GO
