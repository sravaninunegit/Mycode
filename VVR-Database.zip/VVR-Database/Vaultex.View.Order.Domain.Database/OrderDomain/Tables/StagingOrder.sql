CREATE TABLE [dbo].[StagingOrder]
(
    [StagingOrderId] BIGINT IDENTITY(1, 1) NOT NULL,
    [primkey] CHAR(28) NOT NULL, -- primary key for CoC oh_web (concatenation of ordtype+lcuno+ddate+uniqueid)
    [ordtype] VARCHAR(1) NOT NULL, -- order type (C = coin, N = note)
    [lcuno] CHAR(17) NOT NULL, -- CCS customer number
    [ddate] CHAR(8) NOT NULL, -- delivery date (YYYYMMDD)
    [uniqueid] VARCHAR(2) NOT NULL, -- unique id (for ORF originated orders this allows for up to 100 orders per delivery date, per customer, not applicable for web orders; value = 70)
    [totval] DECIMAL(16, 2) NOT NULL, -- order value
    [centre] VARCHAR(4) NOT NULL, -- centre that the order will be fulfilled by 
    [account] VARCHAR(16) NOT NULL, -- customer account number
    [cashSpec] TEXT NOT NULL, -- cash breakdown of the order
    [regStamp] VARCHAR(12) NOT NULL, -- time order was placed in web ordering (YYMMDDHHMMSS)
    [carriertimes] VARCHAR(14) NOT NULL, -- web ordering generated serial number
    [state] VARCHAR(1) NOT NULL, -- order state (0 = registered)
    [CreatedBy] VARCHAR(100) NOT NULL, 
    [CreatedOn] DATETIME2(7) NOT NULL,
    [UpdatedBy] VARCHAR(100) NULL,
    [UpdatedOn] DATETIME2(7) NULL,
    [DeletedBy] VARCHAR(100) NULL,
    [DeletedOn] DATETIME2(7) NULL,
    [RowLockVersion] ROWVERSION NOT NULL,
    [IsActive] BIT NOT NULL,
    [SourceType] [int] NOT NULL
    CONSTRAINT [PK_StagingOrder] PRIMARY KEY CLUSTERED ([StagingOrderId] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[StagingOrder]
ADD CONSTRAINT [DF_OrderDomain_StagingOrder_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[StagingOrder]
ADD CONSTRAINT [DF_OrderDomain_StagingOrder_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[StagingOrder]
ADD CONSTRAINT [DF_OrderDomain_StagingOrder_IsActive]
    DEFAULT (1) FOR [IsActive]
GO

ALTER TABLE [dbo].[StagingOrder]
ADD CONSTRAINT [DF_OrderDomain_StagingOrder_SourceType]
    DEFAULT (0) FOR [SourceType]
GO
