CREATE TABLE [dbo].[OrderMediaSpec]
(
    [OrderMediaSpecId] BIGINT IDENTITY(1,1) NOT NULL, 
    [WebOrderId] BIGINT NOT NULL, 
    [MediaType] VARCHAR(13) NOT NULL,
    [Quantity] INT NOT NULL,
    [CreatedBy] VARCHAR(100) NOT NULL,
    [CreatedOn] DATETIME2(7) NOT NULL,
    [UpdatedBy] VARCHAR(100) NULL,
    [UpdatedOn] DATETIME2(7) NULL,
    [DeletedBy] VARCHAR(100) NULL,
    [DeletedOn] DATETIME2(7) NULL,
    [RowLockVersion] ROWVERSION NOT NULL,
    [IsActive] BIT NOT NULL,
    [SourceType] [int] NOT NULL
    CONSTRAINT [PK_OrderMediaSpec] PRIMARY KEY CLUSTERED ([OrderMediaSpecId] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[OrderMediaSpec]
ADD CONSTRAINT [FK_OrderMediaSpec_ToWebOrder]
    FOREIGN KEY ([WebOrderId])
    REFERENCES [WebOrder]([WebOrderId]);
GO

ALTER TABLE [dbo].[OrderMediaSpec] 
ADD CONSTRAINT [DF_OrderDomain_OrderMediaSpec_CreatedOn] 
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[OrderMediaSpec]
ADD CONSTRAINT [DF_OrderDomain_OrderMediaSpec_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[OrderMediaSpec]
ADD CONSTRAINT [DF_OrderDomain_OrderMediaSpec_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
 ALTER TABLE [dbo].[OrderMediaSpec]
ADD CONSTRAINT [DF_OrderDomain_OrderMediaSpec_SourceType]
    DEFAULT (0) FOR [SourceType]
GO
