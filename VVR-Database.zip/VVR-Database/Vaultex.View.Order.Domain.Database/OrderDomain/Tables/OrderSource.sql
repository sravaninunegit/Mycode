CREATE TABLE [dbo].[OrderSource]
(
    [OrderSourceId] BIGINT IDENTITY(1, 1) NOT NULL,
	[OrderSourceCode] [int] NOT NULL,
    [OrderSourceDescription] VARCHAR(10) NOT NULL, -- (WEB, MANUAL, FILE, IVR)    
    [CreatedBy] VARCHAR(50) NOT NULL, 
    [CreatedOn] DATETIME2(7) NOT NULL,
    [UpdatedBy] VARCHAR(50) NULL,
    [UpdatedOn] DATETIME2(7) NULL,
    [DeletedBy] VARCHAR(50) NULL,
    [DeletedOn] DATETIME2(7) NULL,
    [RowLockVersion] ROWVERSION NOT NULL,
    [IsActive] BIT NOT NULL,    
    CONSTRAINT [PK_OrderSource] PRIMARY KEY CLUSTERED ([OrderSourceId] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[OrderSource]
ADD CONSTRAINT [DF_OrderDomain_OrderSource_CreatedOn]
    DEFAULT (GETDATE()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[OrderSource]
ADD CONSTRAINT [DF_OrderDomain_OrderSource_CreatedBy]
    DEFAULT (SUSER_SNAME()) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[OrderSource]
ADD CONSTRAINT [DF_OrderDomain_OrderSource_IsActive]
    DEFAULT (1) FOR [IsActive]
GO
