BEGIN
MERGE INTO [dbo].[MediaTypeMap] AS t
USING
    (
    SELECT
        s.MediaType,
        s.CCSItId,
        s.Denomination,
		s.UnitsPerPack,
        s.CreatedBy
    FROM
    (
    VALUES
       ('GBPN05000103','NA3P',50.00,50,'DB'),
       ('GBPN02000103','NA4P',20.00,50,'DB'),
       ('GBPN01000103','NA5P',10.00,100,'DB'),
       ('GBPN00500103','NA6P',5.00,100,'DB'),
       ('GBPC00200009','C2SA',2.00,250,'DB'),
       ('GBPC00100009','C3SA',1.00,500,'DB'),
       ('GBPC00050009','C4SA',0.50,500,'DB'),
       ('GBPC00020009','C5SA',0.20,1250,'DB'),
       ('GBPC00010009','C6SA',0.10,1000,'DB'),
       ('GBPC00005009','C7SA',0.05,2000,'DB'),
	   ('GBPC00002009','C8SA',0.02,1000,'DB'),
	   ('GBPC00001009','C9SA',0.01,2000,'DB'),
	   ('GBPC00200015','C2LA',2.00,0,'DB'),
	   ('GBPC00100015','C3LA',1.00,0,'DB'),
	   ('GBPC00050015','C4LA',0.50,0,'DB'),
	   ('GBPC00020015','C5LA',0.20,0,'DB'),
	   ('GBPC00010015','C6LA',0.10,0,'DB'),
	   ('GBPC00005015','C7LA',0.05,0,'DB'),
	   ('GBPC00002015','C8LA',0.02,0,'DB'),
	   ('GBPC00001015','C9LA',0.01,0,'DB')
    ) s (MediaType,CCSItId,Denomination,UnitsPerPack,CreatedBy)
    ) AS s
ON t.MediaType = s.MediaType
WHEN MATCHED AND (
                 t.CCSItId <> s.CCSItId
                 OR t.UnitsPerPack <> s.UnitsPerPack
                 OR t.Denomination <> s.Denomination
                 ) THEN
    UPDATE SET
        t.MediaType = s.MediaType,
        t.CCSItId = s.CCSItId,
        t.Denomination = s.Denomination,
		t.UnitsPerPack=s.UnitsPerPack,
        t.CreatedBy = s.CreatedBy
WHEN NOT MATCHED THEN
    INSERT (
        MediaType,
        CCSItId,
        Denomination,
		UnitsPerPack,
        CreatedBy
       )
    VALUES (
        s.MediaType,
        s.CCSItId,
        s.Denomination,
		s.UnitsPerPack,
        s.CreatedBy
    );
END
