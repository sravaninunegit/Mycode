BEGIN
MERGE INTO [dbo].[OrderSource] AS t
USING
    (
    SELECT
        o.OrderSourceCode,
        o.OrderSourceDescription,       
        o.CreatedBy
    FROM
    (
    VALUES       
	   (1,'WEB','DB'),
	   (2,'BRF','DB'),
	   (3,'IVR','DB'),
	   (4,'MAN','DB')
    ) o (OrderSourceCode,OrderSourceDescription,CreatedBy)
    ) AS o
ON t.OrderSourceDescription = o.OrderSourceDescription
WHEN MATCHED AND (t.OrderSourceCode <> o.OrderSourceCode              
                 ) THEN
    UPDATE SET
        t.OrderSourceCode = o.OrderSourceCode,
        t.OrderSourceDescription = o.OrderSourceDescription,     
        t.CreatedBy = o.CreatedBy
WHEN NOT MATCHED THEN
    INSERT (
        OrderSourceCode,
        OrderSourceDescription,        
        CreatedBy
       )
    VALUES (
        o.OrderSourceCode,
        o.OrderSourceDescription,        
        o.CreatedBy
    );
END
