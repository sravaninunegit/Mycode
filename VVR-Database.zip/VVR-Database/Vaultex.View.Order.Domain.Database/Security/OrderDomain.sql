﻿CREATE SCHEMA [OrderDomain]
    AUTHORIZATION [dbo];