-- =======================================================================
-- Description:	Once database structure updated, execute these SQL scripts
-- History:     26/05/2023 : Wojciech Liguzinski : Created
-- =======================================================================



--          25/02/2022 : Robert Papp : OSET-1424
--			04/05/2022 : Russell Parry : OSET-1719
-- =======================================================================

-- OrderDomain tables
:r OrderDomain\Data\MediaTypeMapping.sql
:r OrderDomain\Data\OrderSourceMapping.sql
